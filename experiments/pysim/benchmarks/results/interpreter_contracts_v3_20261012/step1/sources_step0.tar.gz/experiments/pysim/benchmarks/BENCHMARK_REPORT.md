# PySIM AO-Bench 性能比較（2026-10-12）
<!-- traceability: {ThreadedInterpreter} {Wasm32Only} -->

## フレームポインタ省略・保持のA/B比較（2026-10-12）

LinuxのInterpreter・JITビルドは既定で`-fomit-frame-pointer`を指定している。
直前のWAMR比較も省略指定が有効なビルドである。
現行Clangのx86-64ターゲットでは、O3だけでもdriverの指定は`-mframe-pointer=none`だった。

省略は`-fomit-frame-pointer`、保持は`-fno-omit-frame-pointer -mno-omit-leaf-frame-pointer`で比較した。
ビルド入口の省略指定を上書きするため、比較オプションをClang引数の末尾へ追加した。
O3、NDEBUG、ThinLTO、ソース、AO-Bench入力、CPU 2固定、yieldしきい値4096は共通である。
各条件は3独立プロセス、各3準備実行・7計時とした。
条件とエンジンの実行順を入れ替え、24プロセス、168回を計時した。
全条件で同じ解像度の出力hashが一致した。

代表値は各プロセスの7サンプル中央値を取り、3プロセスの中央値の中央値とした。
括弧内は3プロセス中央値の最小値と最大値である。
短縮率は保持した時間を基準に算出した。

| サイズ | 実行系 | フレームポインタ省略 | フレームポインタ保持 | 省略による時間短縮 |
| :--- | :--- | ---: | ---: | ---: |
| 64×36 | Interpreter | 19.789ms（19.466–20.523） | 20.116ms（20.109–20.349） | 1.63% |
| 64×36 | JIT | 23.206ms（23.049–23.286） | 24.362ms（24.232–25.075） | 4.75% |
| 320×180 | Interpreter | 480.025ms（478.898–482.479） | 492.573ms（486.916–497.637） | 2.55% |
| 320×180 | JIT | 560.045ms（557.768–563.410） | 600.116ms（600.013–601.020） | 6.68% |

320×180では、省略したInterpreterとJITの時間が短かった。
64×36のInterpreterはプロセス中央値の範囲が重なるため、小さな差の再現性は未確認とする。
フレームポインタ省略の効果はあるが、すでに有効であり追加の高速化余地ではない。
この比較でも処理時間の半減は再現しなかった。

Clang driverで省略は`-mframe-pointer=none`、保持は`-mframe-pointer=all`を確認した。
保持したdispatcherは`push rbp; mov rbp, rsp`でフレームポインタを設定した（Intel記法）。
省略したdispatcherにはこの設定がなく、`rbp`は汎用の退避対象レジスタとして使われていた。
`push rbp`の有無だけでフレームポインタの有無を判定しない。
手書きassemblyから生成するJIT stencilの3バイナリは、両条件でhashが同一だった。
今回のオプション差はC++の生成コードに作用し、手書きJIT命令列は変わらない。

全サンプル、ソース・ライブラリhash、driverの指定、dispatcherの逆アセンブルを保存した。
記録は[`native_frame_pointer_ab_20261012.json`](results/native_frame_pointer_ab_20261012.json)である。
使用した計測ドライバは同ファイルの`driver_source`へ保存した。
計測後はassert有効の通常ビルドへ復元した。

## 現行リファクタリング版とWAMRの比較（2026-10-12 13:00）

現行Interpreter・JITとWAMRをClang 21.1.8、O3、NDEBUG、ThinLTOで再ビルドした。
WAMRは2.4.3、commit `f5f57c09aee623436f5fb87a90798fdd2cdf39fd`である。
Fast InterpreterとWASIを有効にし、AOT、LLVM JIT、Fast JITは無効にした。
SIMD、reference types、builtin libcも無効にした。

AO-Benchの同じWASMを5解像度で実行した。
各エンジン・解像度で3独立プロセスを使い、各プロセスで3回準備実行と7回計時を行った。
CPU 2へ固定し、試行ごとにエンジンの実行順を回転した。
計45プロセス、315回の計時であり、全準備実行と計時実行の出力hashを検査した。
同じ解像度の出力hashは全エンジン・全プロセスで一致した。

代表値は各プロセスの7サンプル中央値を取り、3プロセスの中央値の中央値とした。
括弧内は3プロセス中央値の最小値と最大値である。
時間比はFireballの時間をWAMRの時間で割った値であり、大きいほどFireballが遅い。

| サイズ | NativeInterpreter | Hybrid JIT | WAMR Fast | Interpreter/WAMR | JIT/WAMR |
| :--- | ---: | ---: | ---: | ---: | ---: |
| 64×36 | 19.986ms（19.981–20.128） | 23.280ms（23.094–24.026） | 4.813ms（4.760–4.829） | 4.15 | 4.84 |
| 128×72 | 77.752ms（76.411–78.146） | 90.426ms（90.378–92.259） | 19.127ms（18.712–19.446） | 4.07 | 4.73 |
| 192×108 | 173.748ms（173.356–174.370） | 207.754ms（204.422–208.030） | 43.160ms（42.324–43.723） | 4.03 | 4.81 |
| 256×144 | 309.619ms（307.349–312.116） | 363.491ms（363.277–363.602） | 74.207ms（73.698–76.803） | 4.17 | 4.90 |
| 320×180 | 484.928ms（476.147–485.780） | 568.319ms（564.836–576.443） | 119.919ms（118.613–119.954） | 4.04 | 4.74 |

WAMR FastはInterpreterより4.03〜4.17倍、JITより4.73〜4.90倍速かった。
Fireball JITはInterpreterより16.3〜19.6%遅かった。
320×180では17.2%遅く、処理時間を半分以下にする目標は未達である。
以前のWAMR測定とはビルドと出力取得方式が異なるため、個別変更の効果として比較しない。

### 計時範囲と環境

ホストはAMD Ryzen 5 5500GT、Linux x86-64、CPython 3.13.15である。
WASMのhashは`9f5dc300e96641bf040551f9f56cb6e5bda084e98bde83a3fb1cff9a719d49e9`である。
ロード、初期化、ホスト準備、出力読取りとhash検査を計時から除外した。
計時対象は`NativeInterpreter.call()`または`wasm_runtime_call_wasm()`である。

Fireballのyieldしきい値は4096とした。
JIT候補キューは準備実行後に処理し、計時中の`idle_budget`は0とした。
サニタイザとQAカウンタは計時ビルドに含めていない。

FireballはPython WASI/HALとStreamTransportを通る。
WAMRはC WASIからメモリ上のファイルへ出力する。
出力を生成するホスト処理は計時に含むため、ホスト統合を含むワークロード比較である。
命令ディスパッチ単体の時間差や、ARM実機の性能差はこの結果から決定しない。
WAMRのJIT・AOTとの比較は今回の測定範囲に含まない。

### ソースで確認した差と次の計測対象

WAMR FastのLoaderは`local.get`の実行命令を消し、後続演算が参照するフレーム内位置へ置き換える。
定数命令も定数領域の位置へ置き換える経路を持つ。
位置を表せない定数は実行命令として残す。
数値演算は入力二つと出力一つの位置を指定してフレームを直接読む・書く。
根拠はvendoredの[`wasm_loader.c`](../../../third_party/wasm-micro-runtime/core/iwasm/interpreter/wasm_loader.c)と[`wasm_interp_fast.c`](../../../third_party/wasm-micro-runtime/core/iwasm/interpreter/wasm_interp_fast.c)である。

FireballもLoaderで即値を解析済みであり、実行時にWASMのLEBを繰り返し読む方式ではない。
ただしInterpreterの`local.get`と定数ロードは個々のスタック命令として残る。
JITでもRuntime APIへ下げる命令にはABI引数準備、レジスタ退避、状態同期がある。
これらはソース上の差であり、時間差への寄与率は未測定である。
NR-12では命令の消去・位置解決と、Runtime API境界費用を優先して分解する。

### 証跡と再実行

全サンプル、出力hash、ソース・共有ライブラリhash、WAMRのコンパイル設定を保存した。
記録は[`aobench_interpreter_jit_wamr_20261012_refactor.json`](results/aobench_interpreter_jit_wamr_20261012_refactor.json)である。
再計測入口は[`compare_wamr.py`](aobench/compare_wamr.py)である。

```bash
UV_CACHE_DIR=/tmp/fireball-uv-cache bash experiments/pysim/native/tier2_runtime/interpreter/build_native.sh --release
UV_CACHE_DIR=/tmp/fireball-uv-cache bash experiments/pysim/native/tier3_plugins/jit/build_native.sh --release
cmake -S third_party/wasm-micro-runtime/product-mini/platforms/linux -B /tmp/fireball-wamr-fast-o3 \
  -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_FLAGS_RELEASE='-O3 -DNDEBUG -flto=thin' \
  -DCMAKE_CXX_FLAGS_RELEASE='-O3 -DNDEBUG -flto=thin' \
  -DBUILD_SHARED_LIBS=ON -DCMAKE_SHARED_LINKER_FLAGS='-fuse-ld=lld' \
  -DWAMR_BUILD_INTERP=1 -DWAMR_BUILD_FAST_INTERP=1 -DWAMR_BUILD_AOT=0 \
  -DWAMR_BUILD_JIT=0 -DWAMR_BUILD_FAST_JIT=0 -DWAMR_BUILD_LIBC_WASI=1 \
  -DWAMR_BUILD_LIBC_BUILTIN=0 -DWAMR_BUILD_SIMD=0 -DWAMR_BUILD_REF_TYPES=0
cmake --build /tmp/fireball-wamr-fast-o3 --target vmlib -j 4
.venv/bin/python experiments/pysim/benchmarks/aobench/compare_wamr.py \
  --wamr-build /tmp/fireball-wamr-fast-o3 --cpu 2 --trials 3 \
  --output experiments/pysim/benchmarks/results/aobench_interpreter_jit_wamr_20261012_refactor.json
```

## 責務・契約・不変表整理後のO2/O3比較（2026-10-12）

Nativeの命令意味論を独立した翻訳単位へ分け、JITのキャッシュ、履歴・候補、provider接続の責務を整理した。内部契約の重複したエラー経路を削り、静的なPython命令表を不変化した。モジュール分割直後はRuntime APIへの直接呼出しが命令ごとに残っていたため、Runtime API宣言のインライン指定とThinLTOで呼出しを融合した。実装は`.cxx`に置いたままである。生成コードから該当する直接呼出しが消えたことを確認した。

最終ソースをO2とO3でrelease再ビルドした。同じNDEBUG、ThinLTO、AO-Bench 64×36、CPU 2固定、yieldしきい値4096、3独立プロセス、各3 warmup・7 timed callsで比較した。実行順はプロセスごとに入れ替えた。計時前にJIT候補キューを処理し、計時呼出しはidle_budget=0とした。計測区間はNativeInterpreter.call()であり、ロードと準備を含まない。代表値は3プロセスの中央値の中央値である。括弧内はプロセス中央値の最小と最大を示す。

| 最適化 | NativeInterpreter | Hybrid JIT | JIT/Interpreter |
| :--- | ---: | ---: | ---: |
| O2 | 19.707ms（19.438–19.880） | 22.988ms（22.852–23.415） | 1.166 |
| O3 | 19.791ms（19.673–20.089） | 23.090ms（22.986–26.387） | 1.167 |

O3はO2よりInterpreterが0.43%、JITが0.45%遅く、差はプロセス間のばらつきより小さい。この条件ではO3による倍速を再現しなかった。O3のJITはInterpreterより16.7%遅い。処理時間の半減とInterpreterに対する2倍速は未達である。

分割直後のO3はInterpreter 26.572ms、JIT 28.902msだった。ROM表の借用化前の呼出し融合後はInterpreter 19.950ms、JIT 23.158msであり、それぞれ約25%、約20%短い。この差は今回の分割境界で発生した呼出し費用の改善であり、chain逆引き表や他の整理の単独効果とは扱わない。従来版に対する半減の証拠でもない。

関数表の借用化では、JIT共通領域への1,472Bの複製を8Bの参照へ置き換えた。読み取り専用の表はプラグインに一つだけ保持する。API表の参照を置く共通領域の未使用部分をゼロ埋めする処理も削除した。コード領域の予約量は8KBである。借用化前の測定値は[`native_runtime_o2_o3_20261012_before_rom_reference.json`](results/native_runtime_o2_o3_20261012_before_rom_reference.json)に残した。最終値との差は測定のばらつきより小さく、速度差の単独効果は主張しない。

全runのframe SHA-256は`d44fed786dbb555722932e901bd3f56c56aa2daca6c594a67a858c4591e24567`で一致した。全サンプル、ソース・ライブラリ・runner hashは[`native_runtime_o2_o3_20261012.json`](results/native_runtime_o2_o3_20261012.json)へ保存した。分割直後の比較は[`native_runtime_o2_o3_20261012_before_inline.json`](results/native_runtime_o2_o3_20261012_before_inline.json)へ保存した。再計測入口は[`bench_native_build.py`](aobench/bench_native_build.py)である。

```bash
UV_CACHE_DIR=/tmp/fireball-uv-cache bash experiments/pysim/native/tier2_runtime/interpreter/build_native.sh --release
UV_CACHE_DIR=/tmp/fireball-uv-cache bash experiments/pysim/native/tier3_plugins/jit/build_native.sh --release
taskset -c 2 .venv/bin/python experiments/pysim/benchmarks/aobench/bench_native_build.py --engine interpreter
taskset -c 2 .venv/bin/python experiments/pysim/benchmarks/aobench/bench_native_build.py --engine jit
```

ビルド入口の既定最適化はO3である。O2比較ではClang呼出しの末尾へ`-O2`を渡し、それ以外のオプションを維持した。QA計測やサニタイザは計時buildへ合成していない。

静的表の配置も別に確認した。Interpreterのhandler表と属性表、JITのslot表、Runtime API関数表、スコア表はLinuxの実マッピングで読み取り専用だった。pointer再配置が必要な表は`.data.rel.ro`に置かれ、ロード後は`r--p`だった。検査結果は[`native_runtime_readonly_20261012.json`](results/native_runtime_readonly_20261012.json)へ保存した。この結果はARMの物理Flash配置やRAM/ROM予算の適合を証明しない。

## Runtime API命令を含むJIT trace範囲の修正後（最終再計測、2026-10-12）

Loaderのtrace範囲を直接stencilの有無で絞らず、Runtime API loweringされる通常命令も含める修正を反映した最終ソースをrelease再ビルドして計測した。5解像度、3独立プロセス、各3 warmup・7 timed calls、CPU 2固定、yieldしきい値4096、WAMR 2.4.3 Fast Interpreterとの比較である。Python参照Interpreterは対象外とした。全解像度で3実行系のframe hashが一致した。

| サイズ | NativeInterpreter | Hybrid JIT | WAMR Fast |
| :--- | ---: | ---: | ---: |
| 64×36 | 19.477 ms（19.442–19.542） | 25.067 ms（24.907–25.129） | 5.308 ms（5.224–5.385） |
| 128×72 | 74.400 ms（73.972–76.163） | 96.950 ms（96.316–98.123） | 21.556 ms（21.032–22.746） |
| 192×108 | 166.590 ms（165.692–168.090） | 218.846 ms（218.468–221.107） | 46.798 ms（46.583–47.756） |
| 256×144 | 295.573 ms（291.688–297.119） | 390.792 ms（388.355–396.171） | 84.833 ms（83.450–86.489） |
| 320×180 | 463.430 ms（461.691–468.642） | 611.654 ms（607.592–637.384） | 131.888 ms（131.437–132.349） |

計時とは別のQA診断で、320×180のJIT operation bodyを3,947,129回実行し、frame hashも計時runと一致した。修正対象のRuntime API loweringを含むJIT trace経路が実際に動作している。AO-BenchではHybrid JITは全解像度でNativeInterpreterより遅く、320×180では32.0%遅い。WAMR Fastは同サイズでNativeInterpreterの3.51倍、Hybrid JITの4.64倍速かった。この修正でtrace対象範囲と機能の欠落は直ったが、AO-BenchのJIT性能改善は確認できない。個別変更による速度差とは扱わない。全サンプル、出力hash、実行ライブラリとrunnerのSHA-256は[最終計測ログ](results/aobench_interpreter_jit_wamr_20261012_api_span_fix_final.txt)に記録した。

## JIT trace terminal dispatch更新後の再計測（2026-10-12）

JIT traceの正常終端でIPを設定してInterpreterへ戻り、次の基本ブロック設定をInterpreter側で行う変更を含む作業ツリーをreleaseビルドして計測した。前回と同じAO-Bench、5解像度、3独立プロセス、各3 warmup・7 timed calls、CPU 2固定、yieldしきい値4096、WAMR Fast Interpreter比較である。Python参照Interpreterは対象外とした。全解像度でNativeInterpreter、Hybrid JIT、WAMRのフレームhashが一致した。

| サイズ | NativeInterpreter | Hybrid JIT | WAMR Fast |
| :--- | ---: | ---: | ---: |
| 64×36 | 19.390 ms（19.193–19.907） | 25.017 ms（24.972–25.757） | 5.325 ms（5.216–5.326） |
| 128×72 | 75.884 ms（74.780–76.188） | 96.777 ms（96.703–97.946） | 20.843 ms（20.425–20.998） |
| 192×108 | 169.274 ms（169.060–170.083） | 214.921 ms（214.524–215.133） | 47.421 ms（46.457–48.262） |
| 256×144 | 300.114 ms（299.661–300.204） | 383.760 ms（381.374–385.641） | 84.920 ms（83.429–85.327） |
| 320×180 | 468.359 ms（468.153–468.617） | 597.786 ms（593.941–598.083） | 132.697 ms（132.127–144.059） |

320×180ではHybrid JITはInterpreterより27.6%遅く、WAMR FastはInterpreterの3.53倍、Hybrid JITの4.50倍速かった。計時runとは分けたQA診断でも、JIT operation bodyが5,522,136回実行され、trace連結を含むJIT実行経路が有効なことを確認した。診断runのframe hashも一致した。前回値との差は測定変動と複数の作業ツリー変更を含むため、今回のterminal dispatch変更単独の効果とは扱わない。

全プロセスのサンプル、hash、共有ライブラリとrunnerのSHA-256は[2026-10-12 terminal dispatch後の計測ログ](results/aobench_interpreter_jit_wamr_20261012_trace_terminal.txt)に記録した。

## 現行作業ツリーの最新再計測

block-search cacheのhashと関数入口dispatch経路を更新した後、現行作業ツリーからInterpreterとJITをrelease再ビルドして計測した。WAMR Fast Interpreterも同じAO-Bench入力で比較した。5解像度、3独立プロセス、各3 warmup・7 timed calls、CPU 2固定、yieldしきい値4096である。Python参照インタープリタは計時していない。全解像度でInterpreter、Hybrid JIT、WAMRの出力hashが一致した。

| サイズ | NativeInterpreter | Hybrid JIT | WAMR Fast |
| :--- | ---: | ---: | ---: |
| 64×36 | 19.841 ms（19.821–19.848） | 25.926 ms（25.497–26.134） | 5.322 ms（5.287–5.332） |
| 128×72 | 77.411 ms（77.123–77.551） | 101.446 ms（100.737–102.996） | 21.560 ms（21.297–21.829） |
| 192×108 | 173.044 ms（171.280–173.128） | 225.027 ms（222.983–225.496） | 47.474 ms（47.067–47.643） |
| 256×144 | 304.261 ms（304.079–306.671） | 395.313 ms（395.309–398.078） | 86.824 ms（84.903–87.017） |
| 320×180 | 479.342 ms（477.542–482.454） | 621.428 ms（620.282–630.779） | 136.761 ms（134.788–138.940） |

320×180ではHybrid JITがInterpreterより29.6%遅く、WAMRはInterpreterの3.51倍、Hybrid JITの4.54倍速かった。block-search cache単独の効果はAO-Bench 320×180のA/Bでも確認した。cacheありのプロセス中央値はInterpreter 474.013 ms、JIT 618.973 ms、cacheなしはInterpreter 479.675 ms、JIT 623.824 msであり、差はそれぞれ1.18%、0.78%だった。AO-Benchではblock検索cacheの差は小さい。

10,007件のBasicBlockを持つ合成fixtureでは、250,000回のloopを実行し、その後3,334件のcold blockを飛ばした。cacheあり7.460 ms、cacheなし11.224 msで1.505倍だった。大規模block表で同じPCを繰り返し検索する場合には効果があるが、AO-Bench全体の高速化率とは区別する。

全プロセスのサンプル、フレームhash、ライブラリとrunnerのSHA-256は[現行ツリーのInterpreter・JIT・WAMR再計測ログ](results/aobench_interpreter_jit_wamr_20261011_latest_retest.txt)、[AO-Bench block-search cache A/Bログ](results/aobench_block_search_cache_ab_20261011_latest_retest.txt)、[10k BasicBlock block-search cache A/Bログ](results/native_block_search_cache_10k_20261011_latest_retest.txt)に記録した。

## 10,000件BasicBlockでのblock-search cache A/B（初回実装時の履歴）

AO-BenchのBasicBlock数は少ないため、block検索cacheの効果を切り分けられない。10,007件のBasicBlockを持つ合成モジュールを用意し、250,000回のloop実行と3,334件の未実行blockを含む条件でA/B計測した。3独立プロセスすべてでcacheありの方が速く、3試行中央値はcacheあり12.113 ms、cacheなし16.194 ms、1.337倍だった。これはlookupを多く行う合成fixtureでの結果であり、AO-Benchやアプリケーション全体の高速化率を示さない。詳細なサンプルとbuild識別子は[10k BasicBlock cache A/Bログ](results/native_block_search_cache_10k_20261011.txt)に記録した。

## Interpreter block-search cache初回導入時のAO-Bench結果（履歴）

これは2026-10-11に計測した当時のdispatch-local block-search cache実装スナップショットのAO-Bench結果であり、本turnでcache slotのhashと関数入口のdispatch経路を改めた後の再計測値ではない。AO-Benchを従来と同じ5解像度・3独立プロセス・3 warmup・7 timed calls・CPU 2固定・yieldしきい値4096で計測した。当時のInterpreter、Hybrid JIT、WAMR出力は各解像度で一致した。全サンプルは[block-search cache後のAO-Benchログ](results/aobench_interpreter_jit_wamr_20261011_block_search_cache.txt)、cache有無の比較は[block-search cache A/Bログ](results/aobench_block_search_cache_ab_20261011.txt)に記録した。

| サイズ | rays/フレーム | NativeInterpreter | Hybrid JIT | WAMR Fast | JIT/Interpreter | Interpreter/WAMR | JIT/WAMR |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 64×36 | 7,332 | 17.403 ms（17.376–17.495） | 27.777 ms（27.737–27.956） | 5.241 ms（5.231–5.261） | 1.596× | 3.321× | 5.300× |
| 128×72 | 29,732 | 68.146 ms（67.673–68.613） | 109.592 ms（109.459–109.692） | 21.026 ms（20.854–21.119） | 1.608× | 3.241× | 5.212× |
| 192×108 | 67,032 | 152.874 ms（151.460–153.431） | 246.035 ms（245.353–246.093） | 49.084 ms（48.786–49.305） | 1.609× | 3.115× | 5.013× |
| 256×144 | 119,352 | 271.583 ms（269.863–277.551） | 440.613 ms（434.692–442.096） | 86.042 ms（85.116–86.785） | 1.622× | 3.156× | 5.121× |
| 320×180 | 186,792 | 427.135 ms（426.045–428.798） | 695.104 ms（692.933–702.089） | 138.342 ms（136.496–138.541） | 1.627× | 3.088× | 5.025× |

値は各独立プロセス内7サンプルの中央値を取り、3プロセス中央値の中央値を代表値とした。括弧内は3プロセス中央値の最小値と最大値である。320×180のInterpreterは427.135 msで、400 msを超えている。

card-state gate後の基準値との差は、複数の実装変更と測定変動を含むため、block-search cache単独の効果とは扱わない。キャッシュ単独の有無は別のA/Bで確認した。

## card-state gate後の基準結果

block-search cache A/B前に、card-state bitmapでJIT provider lookupをゲートする作業ツリーから計測した値である。計測ソースと実行環境の識別情報は[card-state gate後の再計測ログ](results/aobench_interpreter_jit_wamr_20261011_card_gate.txt)に記録した。

| サイズ | rays/フレーム | NativeInterpreter | Hybrid JIT | WAMR Fast | JIT/Interpreter | Interpreter/WAMR | JIT/WAMR |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 64×36 | 7,332 | 21.030 ms（20.751–21.173） | 32.841 ms（32.592–32.846） | 5.381 ms（5.311–5.516） | 1.562× | 3.908× | 6.103× |
| 128×72 | 29,732 | 81.402 ms（81.384–81.452） | 129.123 ms（128.784–129.539） | 21.636 ms（21.594–22.029） | 1.586× | 3.762× | 5.968× |
| 192×108 | 67,032 | 181.535 ms（181.282–182.085） | 288.043 ms（285.964–290.399） | 48.991 ms（48.940–49.334） | 1.587× | 3.705× | 5.880× |
| 256×144 | 119,352 | 321.336 ms（320.298–326.375） | 513.304 ms（506.936–518.108） | 86.988 ms（85.318–87.576） | 1.597× | 3.694× | 5.901× |
| 320×180 | 186,792 | 508.072 ms（500.646–509.976） | 819.902 ms（801.680–822.724） | 137.818 ms（137.190–138.429） | 1.614× | 3.687× | 5.949× |

値は各独立プロセス内7サンプルの中央値を取り、3プロセス中央値の中央値を代表値とした。括弧内は3プロセス中央値の最小値と最大値である。

## bitmap gate前後の比較

同じ日のbitmap gate前計測と比べたJIT時間を示す。両計測は同一の解像度、yieldしきい値、warmup、試行数、CPU固定条件を使った。

| サイズ | gate前JIT | gate後JIT | 変化 |
| :--- | ---: | ---: | ---: |
| 64×36 | 33.958 ms | 32.841 ms | -3.3% |
| 128×72 | 134.122 ms | 129.123 ms | -3.7% |
| 192×108 | 323.620 ms | 288.043 ms | -11.0% |
| 256×144 | 575.817 ms | 513.304 ms | -10.9% |
| 320×180 | 833.575 ms | 819.902 ms | -1.6% |

320×180ではJIT/Interpreter比が1.644倍から1.614倍へ下がった。JITは全解像度で依然としてNativeInterpreterより遅い。別プロセス計測の変動を含むため、解像度ごとの改善率を厳密な因果効果とは扱わない。

## JIT実行経路の診断

時間計測の終了後、各解像度を独立のQA診断実行に通した。JIT providerのlookup callback呼出し数は、時間計測へ含めていない。

| サイズ | gate前lookup callback | gate後lookup callback | スキップ数 | スキップ率 | gate後hit数 | frame_bytes |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| 64×36 | 732,490 | 238,910 | 493,580 | 67.4% | 238,910 | 2,340 |
| 128×72 | 2,953,224 | 956,191 | 1,997,033 | 67.6% | 956,191 | 9,288 |
| 192×108 | 6,640,775 | 1,959,708 | 4,681,067 | 70.5% | 1,959,708 | 20,844 |
| 256×144 | 11,829,269 | 3,500,988 | 8,328,281 | 70.4% | 3,500,988 | 37,008 |
| 320×180 | 18,498,388 | 5,868,175 | 12,630,213 | 68.3% | 5,868,175 | 57,780 |

Interpreter dispatcherが2-bit card-state bitmapを読み、状態が`COMPILED`でないカードではprovider関数ポインタを呼ばない。AO-Benchではlookup callbackを67〜71%削減した。gate後に呼ばれたcallbackはすべてtrace hitとなった。スキップ件数はgate前後の独立診断実行差分であり、計時run中の厳密な命令数ではない。

## uProf診断

card-state gate前に計測ホスト上でAMD uProf hotspotsをInterpreterとJITの各1回実行した。プロファイラ実行時間は計測オーバーヘッドを含むため通常ベンチマークとの比較には使わず、関数別サンプルの所在だけを診断に使った。Interpreterでは `h_runtime_api<runtime_local_get>` が1.18秒、`h_runtime_api<runtime_call<false>>` が1.06秒、`runtime_end` が0.72秒、`runtime_if` が0.37秒、`runtime_br_if` が0.34秒だった。JITでは `fb_native_run_dispatch_jit` が自己時間2.92秒・子関数込み9.81秒で、同じRuntime APIハンドラ群（call 1.42秒、local_get 0.96秒）に加え `native_jit_plugin::lookup_runtime_trace`（自己時間0.44秒・子関数込み1.05秒）が現れた。これらはgate前のprofileであり、現行経路の関数別割合としては扱わない。

profileのlookup時間とAO-Bench callback差分が同じ箇所を示すため、未コンパイルカードでもJIT providerを呼ぶ処理が余分な経路だったと確認できた。現行dispatcherはbitmapでそれらの呼出しを省く。JIT内のtrace検索とInterpreter Runtime API呼出しは引き続き必要である。uProfのLinux hotspots分析は[AMD uProf CLI Hotspots guide](https://docs.amd.com/r/en-US/68658-uProf-getting-started-guide/Hotspots-Analysis-Using-AMD-uProf-CLI)に従った。

## 計測条件

- 5解像度×3独立プロセス×3エンジンを計測した。各プロセスで3フレームをウォームアップし、後続7フレームを計時した。試行ごとにエンジンの実行順を入れ替え、CPU 2へ固定した。
- InterpreterとHybrid JITは同じNativeInterpreter.call()入口とyieldしきい値4096を使った。Python参照インタープリタは計測対象外とした。
- JITはウォームアップ後にidle_hookで待ち列を処理し、計時呼び出しはidle_budget=0とした。JIT実行カウンターは計時後の独立診断で記録した。
- WASM出力は全15組で一致した。サイズごとの出力SHA-256は64×36: `570ecec0d82c7dfc11805f203e7f5282f12cf1882d0f774783b8d9c057ac5ee2`、128×72: `b6a28d273e549e783d8e5526fd2f9ad1ed8f08b45fba32571f689d7034f6ea03`、192×108: `48b7b02de263c6610328b961fd0f5c2ea901cb82731901b6c36477c0eb913c0c`、256×144: `2ce48b29f0eeabda19490cdf68d35742bbbc837ebb2e6b5d3185df980cdfa67c`、320×180: `b836421dc04ef17309c5bb32b760cdb38f4de85e9cea5943fb90df0697f92f48`。
- WASMのSHA-256は9f5dc300e96641bf040551f9f56cb6e5bda084e98bde83a3fb1cff9a719d49e9。
- CPUはAMD Ryzen 5 5500GT、Linux 7.0.0-38-generic x86_64。CPythonは3.13.15、Clangは21.1.8。
- Interpreter/JIT共有ライブラリは2026-10-11に現行作業ツリーからrelease再ビルドした。WAMRは2.4.3、commit f5f57c09aee623436f5fb87a90798fdd2cdf39fd。Fast Interpreter + WASIを使い、AOT/JITを無効にした。
- WASM解析、ホスト・Interpreter準備、WAMR初期化とmodule load/instantiate、実行環境生成は計時区間から除外した。計時対象は各フレームのNativeInterpreter.call()またはwasm_runtime_call_wasm()である。
- uProf診断はInterpreterとJITを別々に実施した。診断のプロファイラ時間は通常ベンチマークの集計には含めていない。

## 比較上の制約

計測ホストはx86-64である。このAO-Bench結果から、ARMでの大きな即値ロード列とrel経由ロードの速度差は判断できない。ARM上の方式比較にはAArch64実機計測が必要である。また、FireballはPython WASI/HALとStreamTransport、WAMRはC WASIとstdoutを通るため、この値はホスト統合を含むワークロード比較であり、命令ディスパッチ単体の比較ではない。

## 詳細記録

各プロセスの全サンプル、出力ハッシュ、build識別子は[block-search cache後のAO-Benchログ](results/aobench_interpreter_jit_wamr_20261011_block_search_cache.txt)に記録した。キャッシュA/B前のQA診断カウンターと計測識別子は[card-state gate後の再計測ログ](results/aobench_interpreter_jit_wamr_20261011_card_gate.txt)にある。gate前の同条件計測は[gate前ログ](results/aobench_interpreter_jit_wamr_20261011_final_current.txt)、直前のloader更新後計測は[loader更新後ログ](results/aobench_interpreter_jit_wamr_20261011_post_loader.txt)、過去値は[2026-10-07の計測ログ](results/aobench_interpreter_jit_wamr_20261007.txt)にある。

## Interpreter命令幅の固定化（2026-10-12）

<!-- traceability: {ThreadedInterpreter} {GLOBAL_StrictMemoryLimit} -->

命令幅レコードをlittle-endianの固定2byte（u16）へ変更した。65535byteを超える命令は読み込みで拒否する。AO-Benchの全510命令で1byteずつ増え、定数プールは1,946Bから2,456Bへ増えた。増加は510B（26.21%）である。ロード後のアリーナ使用量25,756Bは現行の131,072B上限内だった。このホストの論理容量はMCUの物理予算適合を証明しない。関数別の内訳は[`pool_step0.json`](results/interpreter_contracts_v3_20261012/pool_step0.json)へ保存した。
