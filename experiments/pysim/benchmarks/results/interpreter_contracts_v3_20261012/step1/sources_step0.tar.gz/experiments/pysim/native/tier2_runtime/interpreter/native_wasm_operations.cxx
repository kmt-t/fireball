/** @file @brief 共有のWASM命令意味論と固定スタック操作を実装する。 */
#include "native_wasm_operations.hxx"
#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cmath>
#include <cstring>
#include <functional>
#include <limits>
#include <type_traits>

namespace fireball::wasm_runtime {

const fireball_call_frame_native &active_frame(const execution_context &current) {
  assert(current.call_stack != nullptr);
  assert(current.call_stack->size != 0);
  assert(current.call_stack->size <= FIREBALL_NATIVE_CALL_STACK_CAPACITY);
  assert(current.call_frame_base != nullptr);
  assert(current.call_frame_base >= current.call_stack->frames);
  assert(current.call_frame_base < current.call_stack->frames + current.call_stack->size);
  const auto &frame = current.call_stack->frames[current.call_stack->size - 1];
  assert(frame.function_view != nullptr);
  return frame;
}

const std::uint8_t *interpreter_rel_for_block_index(const fireball_call_frame_native &frame,
                                                    std::uint32_t block_index) {
  assert(frame.function_view != nullptr);
  const auto &function = *frame.function_view;
  assert(function.interpreter_constant_pool != nullptr ||
         function.interpreter_constant_byte_count == 0);
  assert(function.module_view != nullptr);
  const auto &module = *function.module_view;
  assert(module.blocks != nullptr);
  assert(block_index < module.block_count);
  const auto &block = module.blocks[block_index];
  assert(block.function_index == frame.func_index);
  const auto offset = block.interpreter_constant_byte_offset;
  assert(offset != kSentinel);
  assert(offset <= function.interpreter_constant_byte_count);
  if (function.interpreter_constant_pool == nullptr) {
    assert(offset == 0 && function.interpreter_constant_byte_count == 0);
    return nullptr;
  }
  return function.interpreter_constant_pool + offset;
}

const std::uint8_t *interpreter_rel_after_jit_trace(const fireball_call_frame_native &frame,
                                                    std::uint32_t block_index,
                                                    std::uint32_t consumed_bytes) {
  assert(frame.function_view != nullptr);
  const auto &function = *frame.function_view;
  assert(function.module_view != nullptr);
  const auto &module = *function.module_view;
  assert(module.blocks != nullptr);
  assert(block_index < module.block_count);
  assert(module.blocks[block_index].function_index == frame.func_index);
  const auto block_offset = module.blocks[block_index].interpreter_constant_byte_offset;
  assert(block_offset != kSentinel);
  assert(block_offset <= function.interpreter_constant_byte_count);
  assert(consumed_bytes <= function.interpreter_constant_byte_count - block_offset);
  const auto byte_offset = block_offset + consumed_bytes;
  if (function.interpreter_constant_pool == nullptr) {
    assert(byte_offset == 0 && function.interpreter_constant_byte_count == 0);
    return nullptr;
  }
  return function.interpreter_constant_pool + byte_offset;
}

template <typename T> bool opcode_eqz(T value) { return value == 0; }

template <typename T> bool opcode_signed_lt(T left, T right) {
  return static_cast<std::make_signed_t<T>>(left) < static_cast<std::make_signed_t<T>>(right);
}

template <typename T> bool opcode_signed_gt(T left, T right) {
  return static_cast<std::make_signed_t<T>>(left) > static_cast<std::make_signed_t<T>>(right);
}

template <typename T> bool opcode_signed_le(T left, T right) {
  return static_cast<std::make_signed_t<T>>(left) <= static_cast<std::make_signed_t<T>>(right);
}

template <typename T> bool opcode_signed_ge(T left, T right) {
  return static_cast<std::make_signed_t<T>>(left) >= static_cast<std::make_signed_t<T>>(right);
}

template <typename T> T opcode_clz(T value) { return static_cast<T>(std::countl_zero(value)); }

template <typename T> T opcode_ctz(T value) { return static_cast<T>(std::countr_zero(value)); }

template <typename T> T opcode_popcount(T value) { return static_cast<T>(std::popcount(value)); }

template <typename T> T opcode_shift_left(T left, T right) {
  constexpr auto shift_mask = std::numeric_limits<T>::digits - 1;
  return static_cast<T>(left << (right & shift_mask));
}

template <typename T> T opcode_shift_right_signed(T left, T right) {
  using signed_type = std::make_signed_t<T>;
  constexpr auto shift_mask = std::numeric_limits<T>::digits - 1;
  return static_cast<T>(static_cast<signed_type>(left) >> (right & shift_mask));
}

template <typename T> T opcode_shift_right_unsigned(T left, T right) {
  constexpr auto shift_mask = std::numeric_limits<T>::digits - 1;
  return static_cast<T>(left >> (right & shift_mask));
}

template <typename T> T opcode_rotate_left(T left, T right) {
  constexpr auto shift_mask = std::numeric_limits<T>::digits - 1;
  const auto shift = static_cast<unsigned>(right & shift_mask);
  return static_cast<T>((left << shift) |
                        (left >> ((std::numeric_limits<T>::digits - shift) & shift_mask)));
}

template <typename T> T opcode_rotate_right(T left, T right) {
  constexpr auto shift_mask = std::numeric_limits<T>::digits - 1;
  const auto shift = static_cast<unsigned>(right & shift_mask);
  return static_cast<T>((left >> shift) |
                        (left << ((std::numeric_limits<T>::digits - shift) & shift_mask)));
}

template <typename T> bool opcode_div_signed(T left, T right, T &result, std::uint32_t &trap_code) {
  using signed_type = std::make_signed_t<T>;
  const auto signed_left = static_cast<signed_type>(left);
  const auto signed_right = static_cast<signed_type>(right);
  if (signed_right == 0) {
    trap_code = kTrapDivideByZero;
    return false;
  }
  if (signed_left == std::numeric_limits<signed_type>::min() && signed_right == -1) {
    trap_code = kTrapIntegerOverflow;
    return false;
  }
  result = static_cast<T>(signed_left / signed_right);
  trap_code = 0;
  return true;
}

template <typename T>
bool opcode_div_unsigned(T left, T right, T &result, std::uint32_t &trap_code) {
  if (right == 0) {
    trap_code = kTrapDivideByZero;
    return false;
  }
  result = left / right;
  trap_code = 0;
  return true;
}

template <typename T> bool opcode_rem_signed(T left, T right, T &result, std::uint32_t &trap_code) {
  using signed_type = std::make_signed_t<T>;
  const auto signed_left = static_cast<signed_type>(left);
  const auto signed_right = static_cast<signed_type>(right);
  if (signed_right == 0) {
    trap_code = kTrapDivideByZero;
    return false;
  }
  if (signed_left == std::numeric_limits<signed_type>::min() && signed_right == -1) {
    result = 0;
  } else {
    result = static_cast<T>(signed_left % signed_right);
  }
  trap_code = 0;
  return true;
}

template <typename T>
bool opcode_rem_unsigned(T left, T right, T &result, std::uint32_t &trap_code) {
  if (right == 0) {
    trap_code = kTrapDivideByZero;
    return false;
  }
  result = left % right;
  trap_code = 0;
  return true;
}

template <typename T> T opcode_extend8_signed(T value) {
  return static_cast<T>(static_cast<std::int8_t>(value));
}

template <typename T> T opcode_extend16_signed(T value) {
  return static_cast<T>(static_cast<std::int16_t>(value));
}

template <typename T> T opcode_float_abs(T value) { return std::fabs(value); }

template <typename T> T opcode_float_neg(T value) { return -value; }

template <typename T> T opcode_float_ceil(T value) { return std::ceil(value); }

template <typename T> T opcode_float_floor(T value) { return std::floor(value); }

template <typename T> T opcode_float_trunc(T value) { return std::trunc(value); }

template <typename T> T opcode_float_nearest(T value) { return std::nearbyint(value); }

template <typename T> T opcode_float_sqrt(T value) { return std::sqrt(value); }

template <typename T> T opcode_float_div(T left, T right) {
  if (right != 0) {
    return left / right;
  }
  if (left == 0 || std::isnan(left)) {
    return std::numeric_limits<T>::quiet_NaN();
  }
  const auto sign = std::signbit(left) == std::signbit(right) ? T{1} : T{-1};
  return std::copysign(std::numeric_limits<T>::infinity(), sign);
}

template <typename T> T opcode_float_min(T left, T right) {
  if (std::isnan(left) || std::isnan(right)) {
    return std::numeric_limits<T>::quiet_NaN();
  }
  if (left == 0 && right == 0) {
    return std::signbit(left) ? left : right;
  }
  return left < right ? left : right;
}

template <typename T> T opcode_float_max(T left, T right) {
  if (std::isnan(left) || std::isnan(right)) {
    return std::numeric_limits<T>::quiet_NaN();
  }
  if (left == 0 && right == 0) {
    return std::signbit(left) ? right : left;
  }
  return left > right ? left : right;
}

template <typename T> T opcode_float_copysign(T left, T right) {
  return std::copysign(left, right);
}
std::uint32_t control_frame_index(const execution_context &current,
                                  const fireball_control_frame_native *p) {
  assert(current.control_stack != nullptr);
  const auto *begin = current.control_stack->frames;
  assert(p >= begin && p <= begin + FIREBALL_NATIVE_CONTROL_STACK_CAPACITY);
  return static_cast<std::uint32_t>(p - begin);
}

std::uint32_t control_frame_base_index(const execution_context &current) {
  return control_frame_index(current, current.control_frame_base);
}

void record_cps_exit(execution_context &current, std::uint32_t kind) {
  current.runtime_flags = (current.runtime_flags & ~kCpsExitMask) | ((kind + 1) << kCpsExitShift);
}

std::uint32_t cps_exit_kind(const execution_context &current) {
  const auto encoded = (current.runtime_flags & kCpsExitMask) >> kCpsExitShift;
  assert(encoded != 0 && encoded <= 9);
  return encoded - 1;
}

bool cps_exit_pending(const execution_context &current) {
  return (current.runtime_flags & kCpsExitMask) != 0;
}

void clear_cps_exit(execution_context &current) { current.runtime_flags &= ~kCpsExitMask; }

bool runtime_api_boundary(execution_context &current, std::uint32_t ip) {
  current.ip = ip;
  current.trap_code = 0;
  record_cps_exit(current, kRuntimeApiBoundary);
  return false;
}

bool block_boundary(execution_context &current, std::uint32_t ip) {
  current.ip = ip;
  current.trap_code = 0;
  record_cps_exit(current, kBlockBoundary);
  return false;
}

bool complete(execution_context &current) {
  current.ip = kSentinel;
  current.trap_code = 0;
  record_cps_exit(current, kComplete);
  return false;
}

bool trap(execution_context &current, std::uint32_t code) {
  current.trap_code = code;
  record_cps_exit(current, kTrap);
  return false;
}

bool call_boundary(execution_context &current, std::uint32_t ip) {
  current.ip = ip;
  current.trap_code = 0;
  record_cps_exit(current, kCallBoundary);
  return false;
}

bool debug_stop(execution_context &current) {
  current.trap_code = 0;
  record_cps_exit(current, kDebugStop);
  return false;
}

std::uint32_t read_u32(const std::uint8_t *&rel) {
  std::uint32_t value;
  std::memcpy(&value, rel, sizeof(value));
  rel += sizeof(value);
  return value;
}

std::uint32_t instruction_width(const std::uint8_t *rel) {
  std::uint16_t width;
  std::memcpy(&width, rel, sizeof(width));
  return width;
}

void advance_instruction_ip(const std::uint8_t *&ip, const std::uint8_t *&rel) {
  ip += instruction_width(rel);
  rel += sizeof(std::uint16_t);
}

void consume_instruction_width(const std::uint8_t *&rel) {
  rel += sizeof(std::uint16_t);
}

std::uint32_t instruction_offset(const execution_context &current, const std::uint8_t *ip) {
  assert(current.code != nullptr && ip >= current.code && ip <= current.code + current.code_size);
  return static_cast<std::uint32_t>(ip - current.code);
}

std::uint32_t peek_u32(const std::uint8_t *rel) {
  std::uint32_t value = 0;
  std::memcpy(&value, rel, sizeof(value));
  return value;
}

std::int32_t read_s32(const std::uint8_t *&rel) { return static_cast<std::int32_t>(read_u32(rel)); }

std::int64_t read_s64(const std::uint8_t *&rel) {
  std::uint64_t value;
  std::memcpy(&value, rel, sizeof(value));
  rel += sizeof(value);
  return static_cast<std::int64_t>(value);
}

bool pop_u64(execution_context &current, std::uint32_t *&sp, std::uint64_t &value) {
  if (sp < current.stack_base + 2) {
    return false;
  }
  const auto low = sp[-2];
  const auto high = sp[-1];
  sp -= 2;
  value = static_cast<std::uint64_t>(low) | (static_cast<std::uint64_t>(high) << 32);
  return true;
}

bool push_u64(execution_context &current, std::uint32_t *&sp, std::uint64_t value) {
  if (current.stack_limit - sp < 2) {
    return false;
  }
  *sp++ = static_cast<std::uint32_t>(value);
  *sp++ = static_cast<std::uint32_t>(value >> 32);
  return true;
}

std::uint64_t combine_u64(std::uint32_t low, std::uint32_t high) {
  return static_cast<std::uint64_t>(low) | (static_cast<std::uint64_t>(high) << 32);
}

template <bool ResultIsBool>
void replace_u64_operands(std::uint32_t *&sp, std::uint64_t result, std::uint32_t operand_words) {
  constexpr auto result_words = ResultIsBool ? 1u : 2u;
  auto *target = sp - operand_words;
  sp = target + result_words;
  target[0] = static_cast<std::uint32_t>(result);
  if constexpr (!ResultIsBool) {
    target[1] = static_cast<std::uint32_t>(result >> 32);
  }
}

float f32_from_bits(std::uint32_t value) { return std::bit_cast<float>(value); }

std::uint32_t f32_to_bits(float value) { return std::bit_cast<std::uint32_t>(value); }

double f64_from_bits(std::uint64_t value) { return std::bit_cast<double>(value); }

std::uint64_t f64_to_bits(double value) { return std::bit_cast<std::uint64_t>(value); }

bool pop_f32(execution_context &current, std::uint32_t *&sp, float &value) {
  std::uint32_t raw = 0;
  if (!pop(current, sp, raw)) {
    return false;
  }
  value = f32_from_bits(raw);
  return true;
}

bool push_f32(execution_context &current, std::uint32_t *&sp, float value) {
  return push(current, sp, f32_to_bits(value));
}

bool pop_f64(execution_context &current, std::uint32_t *&sp, double &value) {
  std::uint64_t raw = 0;
  if (!pop_u64(current, sp, raw)) {
    return false;
  }
  value = f64_from_bits(raw);
  return true;
}

bool push_f64(execution_context &current, std::uint32_t *&sp, double value) {
  return push_u64(current, sp, f64_to_bits(value));
}

fireball_call_frame_native &active_frame(execution_context &current) {
  assert(current.call_stack != nullptr);
  assert(current.call_stack->size != 0);
  assert(current.call_stack->size <= FIREBALL_NATIVE_CALL_STACK_CAPACITY);
  assert(current.call_frame_base != nullptr);
  assert(current.call_frame_base >= current.call_stack->frames);
  assert(current.call_frame_base < current.call_stack->frames + current.call_stack->size);
  auto &frame = current.call_stack->frames[current.call_stack->size - 1];
  assert(frame.function_view != nullptr);
  return frame;
}

bool finish_current_function(execution_context &current, std::uint32_t *&local_base,
                             const std::uint8_t *&instruction_ip) {
  auto *stack = current.call_stack;
  assert(stack != nullptr);
  assert(stack->size != 0);
  if (&active_frame(current) == current.call_frame_base) {
    current.ip = kSentinel;
    return true;
  }

  const auto finished = stack->frames[stack->size - 1];
  assert(finished.return_ip != kSentinel);
  --stack->size;
  current.local_stack_pointer = finished.local_base;
  current.control_stack->size = control_frame_index(current, finished.control_frame_base);

  auto &caller = stack->frames[stack->size - 1];
  assert(caller.function_view != nullptr);
  local_base = caller.local_base;
  current.local_base = local_base;
  current.code = caller.function_view->code;
  current.code_size = caller.function_view->code_size;
  current.control_frame_base = caller.control_frame_base;
  instruction_ip = current.code + finished.return_ip;
  return false;
}

bool is_requested_block_boundary(const execution_context &current, std::uint32_t ip) {
  const auto &frame = active_frame(current);
  const auto pc = frame.function_view->code_pc_offset + ip;
  return pc == frame.boundary_next_pc || pc == frame.boundary_loops_to;
}

bool should_stop_after_control(const execution_context &current) {
  return (current.runtime_flags & kStopAfterControlFlag) != 0;
}

bool record_loop_backedge(execution_context &current, std::uint32_t source_ip,
                          std::uint32_t target_ip) {
  if (target_ip >= source_ip) {
    return false;
  }
  if (current.loop_jump_count < UINT32_MAX) {
    ++current.loop_jump_count;
  }
  return true;
}

const fireball_control_map_entry_native *control_entry(const execution_context &current,
                                                       std::uint32_t ip) {
  const auto &frame = active_frame(current);
  assert(frame.function_view->control_map != nullptr);
  if (ip >= current.code_size) {
    return nullptr;
  }
  return &frame.function_view->control_map[ip];
}

local_value_span local_span(const fireball_call_frame_native &frame, std::uint32_t index) {
  assert(frame.function_view != nullptr);
  const auto &function = *frame.function_view;
  assert(index < function.local_count);
  const auto offset = function.local_offsets[index];
  const auto width = function.local_sizes[index];
  assert(width == 1 || width == 2);
  assert(offset + width <= function.local_slot_count);
  return {offset, width};
}

bool branch(execution_context &current, std::uint32_t *&sp, std::uint32_t depth,
            std::uint32_t &next_ip) {
  const auto *control_end = current.control_stack->frames + current.control_stack->size;
  const auto frame_count = static_cast<std::uint32_t>(control_end - current.control_frame_base);
  if (depth > frame_count) {
    return false;
  }
  const auto &call_frame = active_frame(current);
  const auto outer_result_arity = call_frame.function_view->result_arity;
  const auto target_index = frame_count - depth - 1;
  std::uint32_t result_arity = outer_result_arity;
  auto *saved_height = current.stack_base;
  const fireball_control_map_entry_native *target_entry = nullptr;
  bool target_is_loop = false;
  if (depth < frame_count) {
    const auto &target = current.control_frame_base[target_index];
    target_entry = control_entry(current, target.start);
    if (target_entry == nullptr || target_entry->match_end == kSentinel) {
      return false;
    }
    assert(target.start < current.code_size);
    target_is_loop = current.code[target.start] == 0x03u;
    saved_height = target.stack_height;
    result_arity = target_is_loop ? 0u : target_entry->result_arity;
  }
  if (result_arity > 2 || saved_height > sp || result_arity > current.stack_limit - saved_height ||
      result_arity > sp - saved_height) {
    return false;
  }
  const auto result0 = result_arity >= 1 ? sp[-static_cast<std::ptrdiff_t>(result_arity)] : 0;
  const auto result1 = result_arity >= 2 ? sp[-1] : 0;
  sp = saved_height;
  if (result_arity >= 1) {
    *sp++ = result0;
  }
  if (result_arity >= 2) {
    *sp++ = result1;
  }
  if (depth == frame_count) {
    current.control_stack->size = control_frame_base_index(current);
    next_ip = kSentinel;
    return true;
  }
  if (target_is_loop) {
    current.control_stack->size = control_frame_base_index(current) + target_index + 1;
    next_ip = target_entry->next_pc;
  } else {
    current.control_stack->size = control_frame_base_index(current) + target_index;
    next_ip = target_entry->match_end + 1;
  }
  return true;
}

void prune_control_frames_after_static_jump(execution_context &current, std::uint32_t target_ip) {
  // A loader-resolved basic-block successor may skip one or more `end`
  // handlers. Drop lexical frames whose ranges no longer contain its target
  // before continuing native dispatch.
  while (current.control_stack->frames + current.control_stack->size > current.control_frame_base) {
    const auto &frame = current.control_stack->frames[current.control_stack->size - 1];
    const auto *entry = control_entry(current, frame.start);
    assert(entry != nullptr && entry->match_end != kSentinel);
    if (target_ip <= entry->match_end) {
      return;
    }
    --current.control_stack->size;
  }
}

bool pop(execution_context &current, std::uint32_t *&sp, std::uint32_t &value) {
  if (sp == current.stack_base) {
    return false;
  }
  value = sp[-1];
  --sp;
  return true;
}

bool push(execution_context &current, std::uint32_t *&sp, std::uint32_t value) {
  if (sp >= current.stack_limit) {
    return false;
  }
  *sp++ = value;
  return true;
}

std::uint64_t opcode_extend32_signed(std::uint64_t value) {
  return static_cast<std::uint64_t>(static_cast<std::int64_t>(static_cast<std::int32_t>(value)));
}

bool linear_memory_range_is_valid(const execution_context &current, std::uint64_t offset,
                                  std::uint32_t length) {
  const auto wide_length = static_cast<std::uint64_t>(length);
  return offset <= current.linear_memory_size && wide_length <= current.linear_memory_size - offset;
}

bool conversion_i32_wrap_i64(execution_context &current, std::uint32_t *&sp,
                             std::uint32_t &trap_code) {
  std::uint64_t value = 0;
  if (!pop_u64(current, sp, value) || !push(current, sp, static_cast<std::uint32_t>(value))) {
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i32_trunc_f32_s(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  float value = 0;
  if (!pop_f32(current, sp, value) || !std::isfinite(value) || value < -2147483648.0f ||
      value >= 2147483648.0f) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  const auto result = static_cast<std::uint32_t>(static_cast<std::int32_t>(value));
  if (!push(current, sp, result)) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i32_trunc_f32_u(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  float value = 0;
  if (!pop_f32(current, sp, value) || !std::isfinite(value) || value <= -1.0f ||
      value >= 4294967296.0f) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  if (!push(current, sp, static_cast<std::uint32_t>(value))) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i32_trunc_f64_s(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  double value = 0;
  if (!pop_f64(current, sp, value) || !std::isfinite(value) || value < -2147483648.0 ||
      value >= 2147483648.0) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  const auto result = static_cast<std::uint32_t>(static_cast<std::int32_t>(value));
  if (!push(current, sp, result)) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i32_trunc_f64_u(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  double value = 0;
  if (!pop_f64(current, sp, value) || !std::isfinite(value) || value <= -1.0 ||
      value >= 4294967296.0) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  if (!push(current, sp, static_cast<std::uint32_t>(value))) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i64_trunc_f32_s(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  float value = 0;
  if (!pop_f32(current, sp, value) || !std::isfinite(value) || value < -9223372036854775808.0f ||
      value >= 9223372036854775808.0f) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  const auto result = value == -9223372036854775808.0f
                          ? 0x8000'0000'0000'0000ull
                          : static_cast<std::uint64_t>(static_cast<std::int64_t>(value));
  if (!push_u64(current, sp, result)) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i64_trunc_f32_u(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  float value = 0;
  if (!pop_f32(current, sp, value) || !std::isfinite(value) || value <= -1.0f ||
      value >= 18446744073709551616.0f) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  if (!push_u64(current, sp, static_cast<std::uint64_t>(value))) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i64_trunc_f64_s(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  double value = 0;
  if (!pop_f64(current, sp, value) || !std::isfinite(value) || value < -9223372036854775808.0 ||
      value >= 9223372036854775808.0) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  const auto result = value == -9223372036854775808.0
                          ? 0x8000'0000'0000'0000ull
                          : static_cast<std::uint64_t>(static_cast<std::int64_t>(value));
  if (!push_u64(current, sp, result)) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i64_trunc_f64_u(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  double value = 0;
  if (!pop_f64(current, sp, value) || !std::isfinite(value) || value <= -1.0 ||
      value >= 18446744073709551616.0) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  if (!push_u64(current, sp, static_cast<std::uint64_t>(value))) {
    trap_code = kTrapInvalidConversion;
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i32_trunc_sat_f32_s(execution_context &current, std::uint32_t *&sp) {
  float value = 0;
  if (!pop_f32(current, sp, value)) {
    return false;
  }
  std::uint32_t result = 0;
  if (std::isnan(value)) {
    result = 0;
  } else if (value <= -2147483648.0f) {
    result = 0x8000'0000u;
  } else if (value >= 2147483648.0f) {
    result = 0x7FFF'FFFFu;
  } else {
    result = static_cast<std::uint32_t>(static_cast<std::int32_t>(value));
  }
  return push(current, sp, result);
}

bool conversion_i32_trunc_sat_f32_u(execution_context &current, std::uint32_t *&sp) {
  float value = 0;
  if (!pop_f32(current, sp, value)) {
    return false;
  }
  std::uint32_t result = 0;
  if (std::isnan(value) || value <= 0.0f) {
    result = 0;
  } else if (value >= 4294967296.0f) {
    result = 0xFFFF'FFFFu;
  } else {
    result = static_cast<std::uint32_t>(value);
  }
  return push(current, sp, result);
}

bool conversion_i32_trunc_sat_f64_s(execution_context &current, std::uint32_t *&sp) {
  double value = 0;
  if (!pop_f64(current, sp, value)) {
    return false;
  }
  std::uint32_t result = 0;
  if (std::isnan(value)) {
    result = 0;
  } else if (value <= -2147483648.0) {
    result = 0x8000'0000u;
  } else if (value >= 2147483648.0) {
    result = 0x7FFF'FFFFu;
  } else {
    result = static_cast<std::uint32_t>(static_cast<std::int32_t>(value));
  }
  return push(current, sp, result);
}

bool conversion_i32_trunc_sat_f64_u(execution_context &current, std::uint32_t *&sp) {
  double value = 0;
  if (!pop_f64(current, sp, value)) {
    return false;
  }
  std::uint32_t result = 0;
  if (std::isnan(value) || value <= 0.0) {
    result = 0;
  } else if (value >= 4294967296.0) {
    result = 0xFFFF'FFFFu;
  } else {
    result = static_cast<std::uint32_t>(value);
  }
  return push(current, sp, result);
}

bool conversion_i64_trunc_sat_f32_s(execution_context &current, std::uint32_t *&sp) {
  float value = 0;
  if (!pop_f32(current, sp, value)) {
    return false;
  }
  std::uint64_t result = 0;
  if (std::isnan(value)) {
    result = 0;
  } else if (value <= -9223372036854775808.0f) {
    result = 0x8000'0000'0000'0000ull;
  } else if (value >= 9223372036854775808.0f) {
    result = 0x7FFF'FFFF'FFFF'FFFFull;
  } else {
    result = static_cast<std::uint64_t>(static_cast<std::int64_t>(value));
  }
  return push_u64(current, sp, result);
}

bool conversion_i64_trunc_sat_f32_u(execution_context &current, std::uint32_t *&sp) {
  float value = 0;
  if (!pop_f32(current, sp, value)) {
    return false;
  }
  std::uint64_t result = 0;
  if (std::isnan(value) || value <= 0.0f) {
    result = 0;
  } else if (value >= 18446744073709551616.0f) {
    result = 0xFFFF'FFFF'FFFF'FFFFull;
  } else {
    result = static_cast<std::uint64_t>(value);
  }
  return push_u64(current, sp, result);
}

bool conversion_i64_trunc_sat_f64_s(execution_context &current, std::uint32_t *&sp) {
  double value = 0;
  if (!pop_f64(current, sp, value)) {
    return false;
  }
  std::uint64_t result = 0;
  if (std::isnan(value)) {
    result = 0;
  } else if (value <= -9223372036854775808.0) {
    result = 0x8000'0000'0000'0000ull;
  } else if (value >= 9223372036854775808.0) {
    result = 0x7FFF'FFFF'FFFF'FFFFull;
  } else {
    result = static_cast<std::uint64_t>(static_cast<std::int64_t>(value));
  }
  return push_u64(current, sp, result);
}

bool conversion_i64_trunc_sat_f64_u(execution_context &current, std::uint32_t *&sp) {
  double value = 0;
  if (!pop_f64(current, sp, value)) {
    return false;
  }
  std::uint64_t result = 0;
  if (std::isnan(value) || value <= 0.0) {
    result = 0;
  } else if (value >= 18446744073709551616.0) {
    result = 0xFFFF'FFFF'FFFF'FFFFull;
  } else {
    result = static_cast<std::uint64_t>(value);
  }
  return push_u64(current, sp, result);
}

bool conversion_i64_extend_i32_s(execution_context &current, std::uint32_t *&sp,
                                 std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value) || !push_u64(current, sp,
                                            static_cast<std::uint64_t>(static_cast<std::int64_t>(
                                                static_cast<std::int32_t>(value))))) {
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_i64_extend_i32_u(execution_context &current, std::uint32_t *&sp,
                                 std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value) || !push_u64(current, sp, value)) {
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_f32_convert_i32_s(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value)) {
    return false;
  }
  return push_f32(current, sp, static_cast<float>(static_cast<std::int32_t>(value)));
}

bool conversion_f32_convert_i32_u(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value)) {
    return false;
  }
  return push_f32(current, sp, static_cast<float>(value));
}

bool conversion_f64_convert_i32_s(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value)) {
    return false;
  }
  return push_f64(current, sp, static_cast<double>(static_cast<std::int32_t>(value)));
}

bool conversion_f64_convert_i32_u(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint32_t value = 0;
  if (!pop(current, sp, value)) {
    return false;
  }
  return push_f64(current, sp, static_cast<double>(value));
}

bool conversion_f32_convert_i64_s(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint64_t value = 0;
  if (!pop_u64(current, sp, value)) {
    return false;
  }
  return push_f32(current, sp, static_cast<float>(static_cast<std::int64_t>(value)));
}

bool conversion_f32_convert_i64_u(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint64_t value = 0;
  if (!pop_u64(current, sp, value)) {
    return false;
  }
  return push_f32(current, sp, static_cast<float>(value));
}

bool conversion_f64_convert_i64_s(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint64_t value = 0;
  if (!pop_u64(current, sp, value)) {
    return false;
  }
  return push_f64(current, sp, static_cast<double>(static_cast<std::int64_t>(value)));
}

bool conversion_f64_convert_i64_u(execution_context &current, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t &trap_code) {
  std::uint64_t value = 0;
  if (!pop_u64(current, sp, value)) {
    return false;
  }
  return push_f64(current, sp, static_cast<double>(value));
}

bool conversion_f64_promote_f32(execution_context &current, std::uint32_t *&sp,
                                std::uint32_t &trap_code) {
  float value = 0;
  if (!pop_f32(current, sp, value) || !push_f64(current, sp, static_cast<double>(value))) {
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_f32_demote_f64(execution_context &current, std::uint32_t *&sp,
                               std::uint32_t &trap_code) {
  double value = 0;
  if (!pop_f64(current, sp, value) || !push_f32(current, sp, static_cast<float>(value))) {
    return false;
  }
  trap_code = 0;
  return true;
}

bool conversion_identity(execution_context &, std::uint32_t *&, std::uint32_t &trap_code) {
  trap_code = 0;
  return true;
}

bool runtime_nop(execution_context *, const std::uint8_t *&instruction_ip,
                 [[maybe_unused]] std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                 [[maybe_unused]] const std::uint8_t *&rel) {
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_else(execution_context *context, const std::uint8_t *&instruction_ip,
                  [[maybe_unused]] std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                  [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (current.control_stack->frames + current.control_stack->size <= current.control_frame_base) {
    return trap(current, kTrapUnreachable);
  }
  const auto frame = current.control_stack->frames[current.control_stack->size - 1];
  current.control_stack->size -= 1;
  const auto &call_frame = active_frame(current);
  const auto *entry = control_entry(current, frame.start);
  assert(entry != nullptr && entry->match_end != kSentinel);
  consume_instruction_width(rel);
  const auto next_ip = call_frame.boundary_next_pc != kSentinel
                           ? call_frame.boundary_next_pc - call_frame.function_view->code_pc_offset
                           : entry->match_end + 1;
  prune_control_frames_after_static_jump(current, next_ip);
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool runtime_block(execution_context *context, const std::uint8_t *&instruction_ip,
                   [[maybe_unused]] std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                   [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto *entry = control_entry(current, source_ip);
  if (entry == nullptr || entry->match_end == kSentinel) {
    return trap(current, kTrapUnreachable);
  }
  if (current.control_stack->size >= FIREBALL_NATIVE_CONTROL_STACK_CAPACITY) {
    return trap(current, kTrapControlFrameCapacity);
  }
  auto &frame = current.control_stack->frames[current.control_stack->size++];
  frame.start = source_ip;
  frame.stack_height = sp;
  consume_instruction_width(rel);
  instruction_ip = current.code + entry->next_pc;
  return block_boundary(current, entry->next_pc);
}

bool runtime_br_if(execution_context *context, const std::uint8_t *&instruction_ip,
                   std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                   [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  std::uint32_t depth = 0;
  std::uint32_t condition = 0;
  depth = read_u32(rel);
  if (!pop(current, sp, condition)) {
    return trap(current, kTrapOperandStackCapacity);
  }
  if (condition == 0) {
    advance_instruction_ip(instruction_ip, rel);
    const auto next_ip = instruction_offset(current, instruction_ip);
    return block_boundary(current, next_ip);
  }
  consume_instruction_width(rel);
  std::uint32_t next_ip = 0;
  if (!branch(current, sp, depth, next_ip)) {
    return trap(current, kTrapUnreachable);
  }
  if (next_ip == kSentinel) {
    const bool outermost = &active_frame(current) == current.call_frame_base;
    if (outermost && should_stop_after_control(current)) {
      return block_boundary(current, kSentinel);
    }
    if (finish_current_function(current, local_base, instruction_ip)) {
      return complete(current);
    }
    return block_boundary(current, instruction_offset(current, instruction_ip));
  }
  const auto &call_frame = active_frame(current);
  if (call_frame.boundary_loops_to != kSentinel) {
    next_ip = call_frame.boundary_loops_to - call_frame.function_view->code_pc_offset;
  }
  prune_control_frames_after_static_jump(current, next_ip);
  record_loop_backedge(current, source_ip, next_ip);
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool apply_local_get(execution_context *context, std::uint32_t *&sp, std::uint32_t *&local_base,
                     const fireball_call_frame_native &frame, std::uint32_t index) {
  auto &current = *context;
  assert(sp >= current.stack_base && sp <= current.stack_limit);
  assert(frame.function_view != nullptr);
  const auto &function = *frame.function_view;
  if (function.local_slot_count == function.local_count) {
    assert(index < function.local_count);
    if (sp == current.stack_limit) {
      return trap(current, kTrapOperandStackCapacity);
    }
    *sp++ = local_base[index];
  } else {
    const auto [offset, width] = local_span(frame, index);
    if (current.stack_limit - sp < width) {
      return trap(current, kTrapOperandStackCapacity);
    }
    if (width == 1) {
      *sp++ = local_base[offset];
    } else {
      sp[0] = local_base[offset];
      sp[1] = local_base[offset + 1];
      sp += 2;
    }
  }
  return true;
}

bool apply_local_set(execution_context *context, std::uint32_t *&sp, std::uint32_t *&local_base,
                     const fireball_call_frame_native &frame, std::uint32_t index) {
  [[maybe_unused]] auto &current = *context;
  const auto &function = *frame.function_view;
  if (function.local_slot_count == function.local_count) {
    assert(index < function.local_count);
    assert(sp >= current.stack_base + 1);
    local_base[index] = sp[-1];
    --sp;
  } else {
    const auto [offset, width] = local_span(frame, index);
    assert(sp >= current.stack_base + width);
    if (width == 1) {
      local_base[offset] = sp[-1];
    } else {
      local_base[offset] = sp[-2];
      local_base[offset + 1] = sp[-1];
    }
    sp -= width;
  }
  return true;
}

bool apply_local_tee(execution_context *context, std::uint32_t *&sp, std::uint32_t *&local_base,
                     const fireball_call_frame_native &frame, std::uint32_t index) {
  [[maybe_unused]] auto &current = *context;
  assert(frame.function_view != nullptr);
  const auto &function = *frame.function_view;
  if (function.local_slot_count == function.local_count) {
    assert(index < function.local_count);
    assert(sp >= current.stack_base + 1);
    local_base[index] = sp[-1];
  } else {
    const auto [offset, width] = local_span(frame, index);
    assert(sp >= current.stack_base + width);
    if (width == 1) {
      local_base[offset] = sp[-1];
    } else {
      local_base[offset] = sp[-2];
      local_base[offset + 1] = sp[-1];
    }
  }
  return true;
}

bool runtime_local_get_decoded(execution_context *context, std::uint32_t *&sp,
                               std::uint32_t *&local_base, std::uint32_t index) {
  auto &current = *context;
  return apply_local_get(context, sp, local_base, active_frame(current), index);
}

bool runtime_local_get(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  const auto index = read_u32(rel);
  if (!runtime_local_get_decoded(context, sp, local_base, index)) {
    return false;
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_local_set_decoded(execution_context *context, std::uint32_t *&sp,
                               std::uint32_t *&local_base, std::uint32_t index) {
  auto &current = *context;
  return apply_local_set(context, sp, local_base, active_frame(current), index);
}

bool runtime_local_set(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  const auto index = read_u32(rel);
  if (!runtime_local_set_decoded(context, sp, local_base, index)) {
    return false;
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_local_tee_decoded(execution_context *context, std::uint32_t *&sp,
                               std::uint32_t *&local_base, std::uint32_t index) {
  auto &current = *context;
  return apply_local_tee(context, sp, local_base, active_frame(current), index);
}

bool runtime_local_tee(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  const auto index = read_u32(rel);
  if (!runtime_local_tee_decoded(context, sp, local_base, index)) {
    return false;
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_global_get(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto index = read_u32(rel);

  const auto &frame = active_frame(current);
  const auto *module = frame.function_view->module_view;
  assert(module != nullptr && index < module->global_count);
  assert(module->globals != nullptr && module->global_widths != nullptr);

  const auto width = module->global_widths[index];
  assert(width == 1u || width == 2u);
  if (current.stack_limit - sp < width) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto value = module->globals[index];
  *sp++ = static_cast<std::uint32_t>(value);
  if (width == 2u) {
    *sp++ = static_cast<std::uint32_t>(value >> 32);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_global_set(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto index = read_u32(rel);

  const auto &frame = active_frame(current);
  const auto *module = frame.function_view->module_view;
  assert(module != nullptr && index < module->global_count);
  assert(module->globals != nullptr && module->global_widths != nullptr);

  const auto width = module->global_widths[index];
  assert(width == 1u || width == 2u);
  if (sp < current.stack_base + width) {
    return trap(current, kTrapOperandStackCapacity);
  }
  auto value = static_cast<std::uint64_t>(sp[-static_cast<std::ptrdiff_t>(width)]);
  if (width == 2u) {
    value |= static_cast<std::uint64_t>(sp[-1]) << 32;
  }
  module->globals[index] = value;
  sp -= width;
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_drop(execution_context *context, const std::uint8_t *&instruction_ip,
                  std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                  [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto *entry = control_entry(current, instruction_offset(current, instruction_ip));
  const auto width = entry == nullptr ? 0u : entry->operand_width;
  if (width == 0 || sp < current.stack_base + width) {
    return trap(current, kTrapOperandStackCapacity);
  }
  sp -= width;
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_select(execution_context *context, const std::uint8_t *&instruction_ip,
                    std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                    [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto *entry = control_entry(current, instruction_offset(current, instruction_ip));
  const auto width = entry == nullptr ? 0u : entry->operand_width;
  if ((width != 1 && width != 2) || sp < current.stack_base + 1 + width * 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto condition = sp[-1];
  --sp;
  if (condition == 0) {
    for (std::uint32_t word = 0; word < width; ++word) {
      sp[word - static_cast<std::ptrdiff_t>(2 * width)] =
          sp[word - static_cast<std::ptrdiff_t>(width)];
    }
  }
  sp -= width;
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_end(execution_context *context, const std::uint8_t *&instruction_ip,
                 [[maybe_unused]] std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                 [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (current.control_stack->frames + current.control_stack->size > current.control_frame_base) {
    current.control_stack->size -= 1;
  }
  advance_instruction_ip(instruction_ip, rel);
  const auto next_ip = instruction_offset(current, instruction_ip);
  if (next_ip >= current.code_size) {
    const bool outermost = &active_frame(current) == current.call_frame_base;
    if (outermost && should_stop_after_control(current)) {
      return block_boundary(current, kSentinel);
    }
    if (finish_current_function(current, local_base, instruction_ip)) {
      return complete(current);
    }
    return block_boundary(current, instruction_offset(current, instruction_ip));
  }
  return block_boundary(current, next_ip);
}

bool runtime_return(execution_context *context, const std::uint8_t *&instruction_ip,
                    [[maybe_unused]] std::uint32_t *&sp,
                    [[maybe_unused]] std::uint32_t *&local_base,
                    [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  consume_instruction_width(rel);
  const bool outermost = &active_frame(current) == current.call_frame_base;
  if (outermost && should_stop_after_control(current)) {
    return block_boundary(current, kSentinel);
  }
  if (finish_current_function(current, local_base, instruction_ip)) {
    return complete(current);
  }
  return block_boundary(current, instruction_offset(current, instruction_ip));
}

bool runtime_br_table(execution_context *context, const std::uint8_t *&instruction_ip,
                      std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                      [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  if (source_ip >= current.code_size) {
    return trap(current, kTrapUnreachable);
  }

  const auto case_count = read_u32(rel);
  if (case_count >= current.code_size) {
    return trap(current, kTrapUnreachable);
  }

  std::uint32_t selector = 0;
  if (!pop(current, sp, selector)) {
    return trap(current, kTrapOperandStackCapacity);
  }

  const auto selected_index = selector < case_count ? selector : case_count;
  std::uint32_t selected_depth = 0;
  for (std::uint32_t index = 0; index <= case_count; ++index) {
    const auto depth = read_u32(rel);
    if (index == selected_index) {
      selected_depth = depth;
    }
  }
  consume_instruction_width(rel);
  std::uint32_t next_ip = 0;
  if (!branch(current, sp, selected_depth, next_ip)) {
    return trap(current, kTrapUnreachable);
  }
  if (next_ip == kSentinel) {
    const bool outermost = &active_frame(current) == current.call_frame_base;
    if (outermost && should_stop_after_control(current)) {
      return block_boundary(current, kSentinel);
    }
    if (finish_current_function(current, local_base, instruction_ip)) {
      return complete(current);
    }
    return block_boundary(current, instruction_offset(current, instruction_ip));
  }
  record_loop_backedge(current, source_ip, next_ip);
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool runtime_i32_const(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto value = read_s32(rel);
  if (!push(current, sp, static_cast<std::uint32_t>(value))) {
    return trap(current, kTrapOperandStackCapacity);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

template <bool (*Operation)(execution_context &, std::uint32_t *&, std::uint32_t &)>
bool runtime_conversion(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  std::uint32_t trap_code = 0;
  if (!Operation(current, sp, trap_code)) {
    return trap(current, trap_code == 0 ? kTrapOperandStackCapacity : trap_code);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_i64_const(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto value = read_s64(rel);
  if (!push_u64(current, sp, static_cast<std::uint64_t>(value))) {
    return trap(current, kTrapOperandStackCapacity);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_f32_const(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  std::uint32_t bits = 0;
  std::memcpy(&bits, instruction_ip + 1, sizeof(bits));
  if (!push(*context, sp, static_cast<std::uint32_t>(bits))) {
    return trap(*context, kTrapOperandStackCapacity);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

bool runtime_f64_const(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  std::uint64_t bits = 0;
  std::memcpy(&bits, instruction_ip + 1, sizeof(bits));
  if (!push_u64(*context, sp, bits)) {
    return trap(*context, kTrapOperandStackCapacity);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}

template <std::uint32_t Width> std::uint64_t sign_extend_memory_value(std::uint64_t value) {
  if constexpr (Width < sizeof(std::uint64_t)) {
    constexpr auto sign_bit = std::uint64_t{1} << (Width * 8 - 1);
    return (value ^ sign_bit) - sign_bit;
  }
  return value;
}

template <bool (*Operation)(execution_context &, std::uint32_t *&)>
bool runtime_fc_saturating_conversion_decoded(execution_context *context, std::uint32_t *&sp) {
  auto &current = *context;
  if (!Operation(current, sp)) {
    return trap(current, kTrapOperandStackCapacity);
  }
  return true;
}

template <bool (*Operation)(execution_context &, std::uint32_t *&)>
bool runtime_fc_saturating_conversion(execution_context *context,
                                      const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                      [[maybe_unused]] std::uint32_t *&local_base,
                                      [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto subopcode = read_u32(rel);
  if (subopcode > 7) {
    return trap(current, kTrapUnreachable);
  }
  const auto next_ip = instruction_offset(current, instruction_ip) + instruction_width(rel);
  consume_instruction_width(rel);
  if (!runtime_fc_saturating_conversion_decoded<Operation>(context, sp)) {
    return false;
  }
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool runtime_memory_manager_api_boundary(execution_context *context,
                                         const std::uint8_t *&instruction_ip,
                                         [[maybe_unused]] std::uint32_t *&sp,
                                         [[maybe_unused]] std::uint32_t *&local_base,
                                         const std::uint8_t *&rel) {
  (void)read_u32(rel);
  const auto source_ip = instruction_offset(*context, instruction_ip);
  consume_instruction_width(rel);
  return runtime_api_boundary(*context, source_ip);
}

template <auto Operation>
bool runtime_i32_unary(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp == current.stack_base) {
    return trap(current, kTrapOperandStackCapacity);
  }
  sp[-1] = Operation(sp[-1]);
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <bool Indirect>
bool runtime_call(execution_context *context, const std::uint8_t *&instruction_ip,
                  std::uint32_t *&sp, std::uint32_t *&local_stack,
                  [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  std::uint32_t function_index = 0;
  [[maybe_unused]] std::uint32_t expected_type_index = 0;
  std::uint32_t table_index = 0;
  std::uint32_t table_slot = 0;
  const auto &caller = active_frame(current);
  assert(caller.function_view->module_view != nullptr);
  const auto &module = *caller.function_view->module_view;

  if constexpr (Indirect) {
    expected_type_index = read_u32(rel);
    table_index = read_u32(rel);
    if (table_index >= module.table_count || module.tables == nullptr) {
      return trap(current, kTrapTableIndexOutOfBounds);
    }
    const auto &table = module.tables[table_index];
    if (sp == current.stack_base) {
      return trap(current, kTrapOperandStackCapacity);
    }
    table_slot = sp[-1];
    if (table_slot >= table.size || table.function_indices == nullptr) {
      return trap(current, kTrapTableIndexOutOfBounds);
    }
    function_index = table.function_indices[table_slot];
    if (function_index == kSentinel) {
      return trap(current, kTrapTableSlotUninitialized);
    }
  } else {
    function_index = read_u32(rel);
  }

  const auto &target = module.functions[function_index];
  // Imports cross the host-call boundary; defined guest functions stay in this
  // native dispatcher and never return to Python opcode handling.
  if (target.is_import != 0) {
    consume_instruction_width(rel);
    return runtime_api_boundary(current, source_ip);
  }
  if constexpr (Indirect) {
    // Imported calls are checked once by the host-call boundary. Defined
    // calls validate only the selected target before entering its body.
    assert(expected_type_index < module.type_count && target.type_index < module.type_count);
    assert(module.types != nullptr && module.signature_bytes != nullptr);
    if (expected_type_index != target.type_index) {
      const auto &expected = module.types[expected_type_index];
      const auto &actual = module.types[target.type_index];
      if (expected.param_count != actual.param_count ||
          expected.result_count != actual.result_count ||
          std::memcmp(module.signature_bytes + expected.param_offset,
                      module.signature_bytes + actual.param_offset, expected.param_count) != 0 ||
          std::memcmp(module.signature_bytes + expected.result_offset,
                      module.signature_bytes + actual.result_offset, expected.result_count) != 0) {
        return trap(current, kTrapIndirectCallTypeMismatch);
      }
    }
  }
  if (current.call_stack->size >= FIREBALL_NATIVE_CALL_STACK_CAPACITY) {
    return trap(current, kTrapCallStackCapacity);
  }
  if (current.local_stack_pointer + target.local_slot_count > current.local_stack_limit) {
    return trap(current, kTrapLocalStackCapacity);
  }

  auto *callee_local_base = current.local_stack_pointer;
  const auto local_end = callee_local_base + target.local_slot_count;
  for (std::uint32_t index = target.param_packed_slot_count; callee_local_base + index < local_end;
       ++index) {
    callee_local_base[index] = 0;
  }

  const auto argument_words = target.param_packed_slot_count + (Indirect ? 1u : 0u);
  if (sp < current.stack_base + argument_words) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto argument_base = sp - static_cast<std::ptrdiff_t>(argument_words);
  const auto *arguments = argument_base;
  auto *argument = arguments;
  for (std::uint32_t index = 0; index < target.param_count; ++index) {
    const auto offset = target.local_offsets[index];
    const auto width = target.local_sizes[index];
    for (std::uint32_t word = 0; word < width; ++word) {
      callee_local_base[offset + word] = *argument++;
    }
  }

  auto &callee = current.call_stack->frames[current.call_stack->size];
  callee.function_view = &target;
  callee.local_base = callee_local_base;
  callee.control_frame_base = current.control_stack->frames + current.control_stack->size;
  callee.func_index = function_index;
  callee.return_ip = source_ip + instruction_width(rel);
  callee.boundary_next_pc = kSentinel;
  callee.boundary_loops_to = kSentinel;
  consume_instruction_width(rel);

  sp = argument_base;
  current.local_stack_pointer = local_end;
  ++current.call_stack->size;
  current.code = target.code;
  current.code_size = target.code_size;
  instruction_ip = current.code;
  current.control_frame_base = callee.control_frame_base;
  local_stack = callee_local_base;
  current.local_base = local_stack;
  return call_boundary(current, 0);
}
template <auto Operation>
bool runtime_i32_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto result = Operation(sp[-2], sp[-1]);
  --sp;
  sp[-1] = result;
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation>
bool runtime_i32_checked_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                                std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                                [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  std::uint32_t result = 0;
  std::uint32_t trap_code = 0;
  if (!Operation(sp[-2], sp[-1], result, trap_code)) {
    return trap(current, trap_code);
  }
  --sp;
  sp[-1] = result;
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation, bool ResultIsBool>
bool runtime_i64_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 4) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto lhs = combine_u64(sp[-4], sp[-3]);
  const auto rhs = combine_u64(sp[-2], sp[-1]);
  const auto result = Operation(lhs, rhs);
  replace_u64_operands<ResultIsBool>(sp, result, 4);
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation, bool ResultIsBool>
bool runtime_i64_checked_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                                std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                                [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 4) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto lhs = combine_u64(sp[-4], sp[-3]);
  const auto rhs = combine_u64(sp[-2], sp[-1]);
  std::uint64_t result = 0;
  std::uint32_t trap_code = 0;
  if (!Operation(lhs, rhs, result, trap_code)) {
    return trap(current, trap_code);
  }
  replace_u64_operands<ResultIsBool>(sp, result, 4);
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation, bool ResultIsBool>
bool runtime_i64_unary(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto value = combine_u64(sp[-2], sp[-1]);
  const auto result = Operation(value);
  replace_u64_operands<ResultIsBool>(sp, result, 2);
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation, bool ResultIsBool>
bool runtime_f32_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto result = Operation(f32_from_bits(sp[-2]), f32_from_bits(sp[-1]));
  --sp;
  if constexpr (ResultIsBool) {
    sp[-1] = static_cast<std::uint32_t>(result);
  } else {
    sp[-1] = f32_to_bits(result);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation, bool ResultIsBool>
bool runtime_f64_binary(execution_context *context, const std::uint8_t *&instruction_ip,
                        std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                        [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 4) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto lhs = f64_from_bits(combine_u64(sp[-4], sp[-3]));
  const auto rhs = f64_from_bits(combine_u64(sp[-2], sp[-1]));
  const auto result = Operation(lhs, rhs);
  if constexpr (ResultIsBool) {
    replace_u64_operands<true>(sp, static_cast<std::uint32_t>(result), 4);
  } else {
    replace_u64_operands<false>(sp, f64_to_bits(result), 4);
  }
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation>
bool runtime_f32_unary(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp == current.stack_base) {
    return trap(current, kTrapOperandStackCapacity);
  }
  sp[-1] = f32_to_bits(Operation(f32_from_bits(sp[-1])));
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <auto Operation>
bool runtime_f64_unary(execution_context *context, const std::uint8_t *&instruction_ip,
                       std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                       [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  if (sp < current.stack_base + 2) {
    return trap(current, kTrapOperandStackCapacity);
  }
  const auto value = f64_from_bits(combine_u64(sp[-2], sp[-1]));
  replace_u64_operands<false>(sp, f64_to_bits(Operation(value)), 2);
  advance_instruction_ip(instruction_ip, rel);
  return true;
}
template <std::uint32_t Width, std::uint32_t ResultWords, bool Signed>
bool runtime_memory_load_decoded(execution_context *context, std::uint32_t *&sp,
                                 [[maybe_unused]] std::uint32_t *&local_base,
                                 const std::uint8_t *&instruction_ip, std::uint32_t source_ip,
                                 std::uint32_t next_pc, std::uint32_t offset) {
  auto &current = *context;
  if (sp == current.stack_base) {
    return trap(current, kTrapOperandStackCapacity);
  }

  const auto address = sp[-1];
  if ((address & 0x8000'0000u) != 0) {
    return runtime_api_boundary(current, source_ip);
  }
  const auto effective_address = static_cast<std::uint64_t>(address) + offset;
  if (!linear_memory_range_is_valid(current, effective_address, Width)) {
    return trap(current, kTrapMemoryOutOfBounds);
  }
  if (current.linear_memory_host_base == nullptr) {
    return runtime_api_boundary(current, source_ip);
  }

  if (current.stack_limit - (sp - 1) < ResultWords) {
    return trap(current, kTrapOperandStackCapacity);
  }
  std::uint64_t value = 0;
  for (std::uint32_t byte = 0; byte < Width; ++byte) {
    value |= static_cast<std::uint64_t>(current.linear_memory_host_base[effective_address + byte])
             << (byte * 8);
  }
  if constexpr (Signed) {
    value = sign_extend_memory_value<Width>(value);
  }

  if constexpr (ResultWords == 2) {
    sp[-1] = static_cast<std::uint32_t>(value);
    *sp++ = static_cast<std::uint32_t>(value >> 32);
  } else {
    sp[-1] = static_cast<std::uint32_t>(value);
  }
  instruction_ip = current.code + next_pc;
  return true;
}
template <std::uint32_t Width, std::uint32_t ResultWords, bool Signed>
bool runtime_memory_load(execution_context *context, const std::uint8_t *&instruction_ip,
                         std::uint32_t *&sp, std::uint32_t *&local_base,
                         [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto alignment = read_u32(rel);
  const auto offset = read_u32(rel);
  (void)alignment;
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto next_ip = source_ip + instruction_width(rel);
  consume_instruction_width(rel);
  return runtime_memory_load_decoded<Width, ResultWords, Signed>(
      context, sp, local_base, instruction_ip, source_ip, next_ip, offset);
}
template <std::uint32_t Width, std::uint32_t ValueWords>
bool runtime_memory_store_decoded(execution_context *context, std::uint32_t *&sp,
                                  [[maybe_unused]] std::uint32_t *&local_base,
                                  const std::uint8_t *&instruction_ip, std::uint32_t source_ip,
                                  std::uint32_t next_pc, std::uint32_t offset) {
  auto &current = *context;
  if (sp < current.stack_base + ValueWords + 1) {
    return trap(current, kTrapOperandStackCapacity);
  }

  auto *address_stack_pointer = sp - ValueWords - 1;
  const auto address = sp[-static_cast<std::ptrdiff_t>(ValueWords + 1)];
  if ((address & 0x8000'0000u) != 0) {
    return runtime_api_boundary(current, source_ip);
  }
  const auto effective_address = static_cast<std::uint64_t>(address) + offset;
  if (!linear_memory_range_is_valid(current, effective_address, Width)) {
    return trap(current, kTrapMemoryOutOfBounds);
  }
  if (current.linear_memory_host_base == nullptr) {
    return runtime_api_boundary(current, source_ip);
  }

  std::uint64_t value = sp[-static_cast<std::ptrdiff_t>(ValueWords)];
  if constexpr (ValueWords == 2) {
    value |= static_cast<std::uint64_t>(sp[-1]) << 32;
  }
  for (std::uint32_t byte = 0; byte < Width; ++byte) {
    current.linear_memory_host_base[effective_address + byte] =
        static_cast<std::uint8_t>(value >> (byte * 8));
  }
  sp = address_stack_pointer;
  instruction_ip = current.code + next_pc;
  return true;
}
template <std::uint32_t Width, std::uint32_t ValueWords>
bool runtime_memory_store(execution_context *context, const std::uint8_t *&instruction_ip,
                          std::uint32_t *&sp, std::uint32_t *&local_base,
                          [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto alignment = read_u32(rel);
  const auto offset = read_u32(rel);
  (void)alignment;
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto next_ip = source_ip + instruction_width(rel);
  consume_instruction_width(rel);
  return runtime_memory_store_decoded<Width, ValueWords>(context, sp, local_base, instruction_ip,
                                                         source_ip, next_ip, offset);
}
bool runtime_if(execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                [[maybe_unused]] std::uint32_t *&local_base,
                [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto *entry = control_entry(current, source_ip);
  std::uint32_t condition = 0;
  if (entry == nullptr || entry->match_end == kSentinel) {
    return trap(current, kTrapUnreachable);
  }
  if (!pop(current, sp, condition)) {
    return trap(current, kTrapOperandStackCapacity);
  }
  consume_instruction_width(rel);
  if (condition == 0 && entry->else_offset == kSentinel) {
    const auto next_ip = entry->match_end + 1;
    instruction_ip = current.code + next_ip;
    return block_boundary(current, next_ip);
  }
  if (current.control_stack->size >= FIREBALL_NATIVE_CONTROL_STACK_CAPACITY) {
    return trap(current, kTrapControlFrameCapacity);
  }
  auto &frame = current.control_stack->frames[current.control_stack->size++];
  frame.start = source_ip;
  frame.stack_height = sp;
  const auto next_ip = condition == 0 ? entry->else_offset + 1 : entry->next_pc;
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool runtime_br(execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                [[maybe_unused]] std::uint32_t *&local_base,
                [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto depth = read_u32(rel);
  consume_instruction_width(rel);
  std::uint32_t next_ip = 0;
  if (!branch(current, sp, depth, next_ip)) {
    return trap(current, kTrapUnreachable);
  }
  if (next_ip == kSentinel) {
    const bool outermost = &active_frame(current) == current.call_frame_base;
    if (outermost && should_stop_after_control(current)) {
      return block_boundary(current, kSentinel);
    }
    if (finish_current_function(current, local_base, instruction_ip)) {
      return complete(current);
    }
    return block_boundary(current, instruction_offset(current, instruction_ip));
  }
  const auto &call_frame = active_frame(current);
  if (call_frame.boundary_next_pc != kSentinel) {
    next_ip = call_frame.boundary_next_pc - call_frame.function_view->code_pc_offset;
  }
  prune_control_frames_after_static_jump(current, next_ip);
  record_loop_backedge(current, source_ip, next_ip);
  instruction_ip = current.code + next_ip;
  return block_boundary(current, next_ip);
}

bool runtime_fc_memory_copy_decoded(execution_context *context, std::uint32_t *&sp,
                                    const std::uint8_t *&instruction_ip, std::uint32_t source_ip,
                                    std::uint32_t next_pc) {
  auto &current = *context;
  if (sp < current.stack_base + 3) {
    return trap(current, kTrapOperandStackCapacity);
  }

  auto *destination_stack_pointer = sp - 3;
  const auto destination = sp[-3];
  const auto source = sp[-2];
  const auto length = sp[-1];
  if (((destination | source) & 0x8000'0000u) != 0) {
    return runtime_api_boundary(current, source_ip);
  }
  if (!linear_memory_range_is_valid(current, destination, length) ||
      !linear_memory_range_is_valid(current, source, length)) {
    return trap(current, kTrapMemoryOutOfBounds);
  }
  if (length != 0) {
    if (current.linear_memory_host_base == nullptr) {
      return runtime_api_boundary(current, source_ip);
    }
    auto *memory = current.linear_memory_host_base;
    std::memmove(memory + destination, memory + source, length);
  }
  sp = destination_stack_pointer;
  instruction_ip = current.code + next_pc;
  return true;
}

bool runtime_fc_memory_copy(execution_context *context, const std::uint8_t *&instruction_ip,
                            std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                            [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto subopcode = read_u32(rel);
  const auto destination_memory = read_u32(rel);
  const auto source_memory = read_u32(rel);
  if (subopcode != 0x0A || destination_memory != 0 || source_memory != 0) {
    return trap(current, kTrapUnreachable);
  }
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto next_ip = source_ip + instruction_width(rel);
  consume_instruction_width(rel);
  if (!runtime_fc_memory_copy_decoded(context, sp, instruction_ip, source_ip, next_ip)) {
    return false;
  }
  return block_boundary(current, next_ip);
}

bool runtime_fc_memory_fill_decoded(execution_context *context, std::uint32_t *&sp,
                                    const std::uint8_t *&instruction_ip, std::uint32_t source_ip,
                                    std::uint32_t next_pc) {
  auto &current = *context;
  if (sp < current.stack_base + 3) {
    return trap(current, kTrapOperandStackCapacity);
  }

  auto *destination_stack_pointer = sp - 3;
  const auto destination = sp[-3];
  const auto value = static_cast<std::uint8_t>(sp[-2]);
  const auto length = sp[-1];
  if (!linear_memory_range_is_valid(current, destination, length)) {
    return trap(current, kTrapMemoryOutOfBounds);
  }
  if (length != 0) {
    if (current.linear_memory_host_base == nullptr) {
      return runtime_api_boundary(current, source_ip);
    }
    std::memset(current.linear_memory_host_base + destination, value, length);
  }
  sp = destination_stack_pointer;
  instruction_ip = current.code + next_pc;
  return true;
}

bool runtime_fc_memory_fill(execution_context *context, const std::uint8_t *&instruction_ip,
                            std::uint32_t *&sp, [[maybe_unused]] std::uint32_t *&local_base,
                            [[maybe_unused]] const std::uint8_t *&rel) {
  auto &current = *context;
  const auto subopcode = read_u32(rel);
  const auto memory_index = read_u32(rel);
  if (subopcode != 0x0B || memory_index != 0) {
    return trap(current, kTrapUnreachable);
  }
  const auto source_ip = instruction_offset(current, instruction_ip);
  const auto next_ip = source_ip + instruction_width(rel);
  consume_instruction_width(rel);
  if (!runtime_fc_memory_fill_decoded(context, sp, instruction_ip, source_ip, next_ip)) {
    return false;
  }
  return block_boundary(current, next_ip);
}

template bool runtime_call<false>(execution_context *context, const std::uint8_t *&instruction_ip,
                                  std::uint32_t *&sp, std::uint32_t *&local_stack,
                                  [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_call<true>(execution_context *context, const std::uint8_t *&instruction_ip,
                                 std::uint32_t *&sp, std::uint32_t *&local_stack,
                                 [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f32_convert_i32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f32_convert_i32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f32_convert_i64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f32_convert_i64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f32_demote_f64>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f64_convert_i32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f64_convert_i32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f64_convert_i64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f64_convert_i64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_f64_promote_f32>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i32_trunc_f32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i32_trunc_f32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i32_trunc_f64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i32_trunc_f64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i32_wrap_i64>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_extend_i32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_extend_i32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_trunc_f32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_trunc_f32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_trunc_f64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_i64_trunc_f64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_conversion<conversion_identity>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<&opcode_float_copysign<float>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<&opcode_float_div<float>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<&opcode_float_max<float>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<&opcode_float_min<float>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::greater<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::greater_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::less<>{}, true>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::less_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::minus<>{}, false>(execution_context *context,
                                                        const std::uint8_t *&instruction_ip,
                                                        std::uint32_t *&sp,
                                                        [[maybe_unused]] std::uint32_t *&local_base,
                                                        [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::multiplies<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::not_equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_binary<std::plus<>{}, false>(execution_context *context,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_abs<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_ceil<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_floor<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_nearest<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_neg<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_sqrt<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f32_unary<&opcode_float_trunc<float>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<&opcode_float_copysign<double>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<&opcode_float_div<double>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<&opcode_float_max<double>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<&opcode_float_min<double>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::greater<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::greater_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::less<>{}, true>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::less_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::minus<>{}, false>(execution_context *context,
                                                        const std::uint8_t *&instruction_ip,
                                                        std::uint32_t *&sp,
                                                        [[maybe_unused]] std::uint32_t *&local_base,
                                                        [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::multiplies<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::not_equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_binary<std::plus<>{}, false>(execution_context *context,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_abs<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_ceil<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_floor<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_nearest<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_neg<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_sqrt<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_f64_unary<&opcode_float_trunc<double>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i32_trunc_sat_f32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i32_trunc_sat_f32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i32_trunc_sat_f64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i32_trunc_sat_f64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i64_trunc_sat_f32_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i64_trunc_sat_f32_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i64_trunc_sat_f64_s>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_fc_saturating_conversion<conversion_i64_trunc_sat_f64_u>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_rotate_left<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_rotate_right<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_shift_left<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_shift_right_signed<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_shift_right_unsigned<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_signed_ge<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_signed_gt<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_signed_le<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<&opcode_signed_lt<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::bit_and<>{}>(execution_context *context,
                                                   const std::uint8_t *&instruction_ip,
                                                   std::uint32_t *&sp,
                                                   [[maybe_unused]] std::uint32_t *&local_base,
                                                   [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::bit_or<>{}>(execution_context *context,
                                                  const std::uint8_t *&instruction_ip,
                                                  std::uint32_t *&sp,
                                                  [[maybe_unused]] std::uint32_t *&local_base,
                                                  [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::bit_xor<>{}>(execution_context *context,
                                                   const std::uint8_t *&instruction_ip,
                                                   std::uint32_t *&sp,
                                                   [[maybe_unused]] std::uint32_t *&local_base,
                                                   [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::equal_to<>{}>(execution_context *context,
                                                    const std::uint8_t *&instruction_ip,
                                                    std::uint32_t *&sp,
                                                    [[maybe_unused]] std::uint32_t *&local_base,
                                                    [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::greater<>{}>(execution_context *context,
                                                   const std::uint8_t *&instruction_ip,
                                                   std::uint32_t *&sp,
                                                   [[maybe_unused]] std::uint32_t *&local_base,
                                                   [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::greater_equal<>{}>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::less<>{}>(execution_context *context,
                                                const std::uint8_t *&instruction_ip,
                                                std::uint32_t *&sp,
                                                [[maybe_unused]] std::uint32_t *&local_base,
                                                [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::less_equal<>{}>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::minus<>{}>(execution_context *context,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::multiplies<>{}>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::not_equal_to<>{}>(execution_context *context,
                                                        const std::uint8_t *&instruction_ip,
                                                        std::uint32_t *&sp,
                                                        [[maybe_unused]] std::uint32_t *&local_base,
                                                        [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_binary<std::plus<>{}>(execution_context *context,
                                                const std::uint8_t *&instruction_ip,
                                                std::uint32_t *&sp,
                                                [[maybe_unused]] std::uint32_t *&local_base,
                                                [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_checked_binary<&opcode_div_signed<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_checked_binary<&opcode_div_unsigned<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_checked_binary<&opcode_rem_signed<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_checked_binary<&opcode_rem_unsigned<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_clz<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_ctz<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_eqz<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_extend16_signed<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_extend8_signed<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i32_unary<&opcode_popcount<std::uint32_t>>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_rotate_left<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_rotate_right<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_shift_left<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_shift_right_signed<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_shift_right_unsigned<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_signed_ge<std::uint64_t>, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_signed_gt<std::uint64_t>, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_signed_le<std::uint64_t>, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<&opcode_signed_lt<std::uint64_t>, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::bit_and<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::bit_or<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::bit_xor<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::greater<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::greater_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::less<>{}, true>(execution_context *context,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::less_equal<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::minus<>{}, false>(execution_context *context,
                                                        const std::uint8_t *&instruction_ip,
                                                        std::uint32_t *&sp,
                                                        [[maybe_unused]] std::uint32_t *&local_base,
                                                        [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::multiplies<>{}, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::not_equal_to<>{}, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_binary<std::plus<>{}, false>(execution_context *context,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_checked_binary<&opcode_div_signed<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_checked_binary<&opcode_div_unsigned<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_checked_binary<&opcode_rem_signed<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_checked_binary<&opcode_rem_unsigned<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_clz<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_ctz<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_eqz<std::uint64_t>, true>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_extend16_signed<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_extend32_signed, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_extend8_signed<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_i64_unary<&opcode_popcount<std::uint64_t>, false>(
    execution_context *context, const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
    [[maybe_unused]] std::uint32_t *&local_base, [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<1, 1, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<1, 1, true>(execution_context *context,
                                              const std::uint8_t *&instruction_ip,
                                              std::uint32_t *&sp, std::uint32_t *&local_base,
                                              [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<1, 2, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<1, 2, true>(execution_context *context,
                                              const std::uint8_t *&instruction_ip,
                                              std::uint32_t *&sp, std::uint32_t *&local_base,
                                              [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<2, 1, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<2, 1, true>(execution_context *context,
                                              const std::uint8_t *&instruction_ip,
                                              std::uint32_t *&sp, std::uint32_t *&local_base,
                                              [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<2, 2, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<2, 2, true>(execution_context *context,
                                              const std::uint8_t *&instruction_ip,
                                              std::uint32_t *&sp, std::uint32_t *&local_base,
                                              [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<4, 1, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<4, 2, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<4, 2, true>(execution_context *context,
                                              const std::uint8_t *&instruction_ip,
                                              std::uint32_t *&sp, std::uint32_t *&local_base,
                                              [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load<8, 2, false>(execution_context *context,
                                               const std::uint8_t *&instruction_ip,
                                               std::uint32_t *&sp, std::uint32_t *&local_base,
                                               [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<1, 1>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<1, 2>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<2, 1>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<2, 2>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<4, 1>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<4, 2>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_store<8, 2>(execution_context *context,
                                         const std::uint8_t *&instruction_ip, std::uint32_t *&sp,
                                         std::uint32_t *&local_base,
                                         [[maybe_unused]] const std::uint8_t *&rel);
template bool runtime_memory_load_decoded<4, 1, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<8, 2, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<1, 1, true>(execution_context *context,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t source_ip,
                                                      std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<1, 1, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<2, 1, true>(execution_context *context,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t source_ip,
                                                      std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<2, 1, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<1, 2, true>(execution_context *context,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t source_ip,
                                                      std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<1, 2, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<2, 2, true>(execution_context *context,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t source_ip,
                                                      std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<2, 2, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<4, 2, true>(execution_context *context,
                                                      std::uint32_t *&sp,
                                                      [[maybe_unused]] std::uint32_t *&local_base,
                                                      const std::uint8_t *&instruction_ip,
                                                      std::uint32_t source_ip,
                                                      std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_load_decoded<4, 2, false>(execution_context *context,
                                                       std::uint32_t *&sp,
                                                       [[maybe_unused]] std::uint32_t *&local_base,
                                                       const std::uint8_t *&instruction_ip,
                                                       std::uint32_t source_ip,
                                                       std::uint32_t next_pc, std::uint32_t offset);
template bool runtime_memory_store_decoded<4, 1>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<8, 2>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<1, 1>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<2, 1>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<1, 2>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<2, 2>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool runtime_memory_store_decoded<4, 2>(execution_context *context, std::uint32_t *&sp,
                                                 [[maybe_unused]] std::uint32_t *&local_base,
                                                 const std::uint8_t *&instruction_ip,
                                                 std::uint32_t source_ip, std::uint32_t next_pc,
                                                 std::uint32_t offset);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i32_trunc_sat_f32_s>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i32_trunc_sat_f32_u>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i32_trunc_sat_f64_s>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i32_trunc_sat_f64_u>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i64_trunc_sat_f32_s>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i64_trunc_sat_f32_u>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i64_trunc_sat_f64_s>(execution_context *context,
                                                                         std::uint32_t *&sp);
template bool
runtime_fc_saturating_conversion_decoded<conversion_i64_trunc_sat_f64_u>(execution_context *context,
                                                                         std::uint32_t *&sp);
} // namespace fireball::wasm_runtime
